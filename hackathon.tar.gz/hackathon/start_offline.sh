#export CATALINA_BASE=apache-tomcat-8.0.28
#echo $CATALINA_BASE
#export CATALINA_HOME=apache-tomcat-8.0.28
#echo $CATALINA_HOME
#sudo apache-tomcat-8.0.28/bin/startup.sh
#cd ./source
#javac Server.java
#java -server -Xms512m -Xmx512m -Xmn768m -classpath . Server


export JAVA_ARGS="
-server
-Xmx2000M
-Xms2000M
-Xmn1500M
-XX:+UseConcMarkSweepGC
-XX:+UseParNewGC
-XX:+CMSParallelRemarkEnabled
-XX:+UseCMSCompactAtFullCollection
-XX:CMSFullGCsBeforeCompaction=0
-XX:+CMSClassUnloadingEnabled
-XX:LargePageSizeInBytes=128M
-XX:+UseFastAccessorMethods
-XX:+UseCMSInitiatingOccupancyOnly
-XX:CMSInitiatingOccupancyFraction=70
-XX:SoftRefLRUPolicyMSPerMB=0
-Xloggc:.logs/gc.log 
-XX:+PrintGCDetails 
-XX:+PrintGCDateStamps"

apt-get install ant
redis-cli -h $REDIS_HOST flushdb
cd ./hackathon 
ant
cd ..
export JETTY_HOME=$(pwd)/jetty
export JETTY_BASE=$(pwd)/jetty
#export JETTY_ARGS=jetty.port=$APP_PORT
#export JETTY_HOST=0.0.0.0
cd $JETTY_HOME
#cd ./tomcat/bin
java -jar $JAVA_ARGS ./start.jar  
#./startup.sh
#jetty.port=$APP_PORT 

#./jetty.sh

