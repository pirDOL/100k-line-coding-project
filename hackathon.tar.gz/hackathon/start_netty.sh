#export CATALINA_BASE=apache-tomcat-8.0.28
#echo $CATALINA_BASE
#export CATALINA_HOME=apache-tomcat-8.0.28
#echo $CATALINA_HOME
#sudo apache-tomcat-8.0.28/bin/startup.sh
#cd ./source
#javac Server.java
#java -server -Xms512m -Xmx512m -Xmn768m -classpath . Server

apt-get install ant
cd ./hackathon_netty
ant
cd ..
export JAVA_ARGS="
-server
-Xmx2800M
-Xms2800M
-Xmn1500M
-XX:PermSize=500M
-XX:MaxPermSize=500M
-Xss256K
-XX:+DisableExplicitGC
-XX:SurvivorRatio=1
-XX:+UseConcMarkSweepGC
-XX:+UseParNewGC
-XX:+CMSParallelRemarkEnabled
-XX:+UseCMSCompactAtFullCollection
-XX:CMSFullGCsBeforeCompaction=0
-XX:+CMSClassUnloadingEnabled
-XX:LargePageSizeInBytes=128M
-XX:+UseFastAccessorMethods
-XX:+UseCMSInitiatingOccupancyOnly
-XX:CMSInitiatingOccupancyFraction=70
-XX:SoftRefLRUPolicyMSPerMB=0"

export GC_ARGS="
-Xloggc:./gc.log 
-XX:+PrintGCDetails 
-XX:+PrintGCDateStamps"
cd ./hackathon_netty/out
java -jar -server -Xmx3200M -Xms3200M -Xmn2000M -XX:+UseConcMarkSweepGC -XX:+UseParNewGC -XX:+CMSParallelRemarkEnabled -XX:+UseCMSCompactAtFullCollection -XX:CMSFullGCsBeforeCompaction=0 -XX:+CMSClassUnloadingEnabled ./hackathon.jar
