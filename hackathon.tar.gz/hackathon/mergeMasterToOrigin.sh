git checkout master
git merge dev
git push origin master
git checkout dev
