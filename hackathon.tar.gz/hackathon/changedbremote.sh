export APP_HOST=0.0.0.0
export APP_PORT=8080
export DB_HOST=223.3.62.220
export DB_USER=guest
export DB_PASS=111111
export REDIS_HOST=223.3.62.220
