#export CATALINA_BASE=apache-tomcat-8.0.28
#echo $CATALINA_BASE
#export CATALINA_HOME=apache-tomcat-8.0.28
#echo $CATALINA_HOME
#sudo apache-tomcat-8.0.28/bin/startup.sh
#cd ./source
#javac Server.java
#java -server -Xms512m -Xmx512m -Xmn768m -classpath . Server

sysctl -w net.core.rmem_max=16777216
sysctl -w net.core.wmem_max=16777216
sysctl -w net.ipv4.tcp_rmem="4096 87380 16777216"
sysctl -w net.ipv4.tcp_wmem="4096 16384 16777216"
sysctl -w net.core.somaxconn=4096
sysctl -w net.core.netdev_max_backlog=16384
sysctl -w net.ipv4.tcp_max_syn_backlog=8192
sysctl -w net.ipv4.tcp_syncookies=1
sysctl -w net.ipv4.ip_local_port_range="1024 65535"
sysctl -w net.ipv4.tcp_tw_recycle=1

apt-get install ant
cd ./hackathon 
ant
cd ..
export JAVA_ARGS="
-server
-Xmx3000M
-Xms3000M
-Xmn2000M
-XX:+UseConcMarkSweepGC
-XX:+UseParNewGC
-XX:+CMSParallelRemarkEnabled
-XX:+CMSClassUnloadingEnabled
-XX:+UseFastAccessorMethods
-XX:+UseCMSInitiatingOccupancyOnly
-XX:CMSInitiatingOccupancyFraction=70
-XX:SoftRefLRUPolicyMSPerMB=0"

export JETTY_HOME=$(pwd)/jetty
export JETTY_BASE=$(pwd)/jetty
#export JETTY_ARGS=jetty.port=$APP_PORT
#export JETTY_HOST=0.0.0.0
cd $JETTY_HOME
#java -jar -server $JETTY_HOME/start.jar jetty.port=$APP_PORT 
java -jar $JAVA_ARGS ./start.jar jetty.host=$APP_HOST jetty.port=$APP_PORT
#./jetty.sh

