#export CATALINA_BASE=apache-tomcat-8.0.28
#echo $CATALINA_BASE
#export CATALINA_HOME=apache-tomcat-8.0.28
#echo $CATALINA_HOME
#sudo apache-tomcat-8.0.28/bin/startup.sh
#cd ./source
#javac Server.java
#java -server -Xms512m -Xmx512m -Xmn768m -classpath . Server

apt-get install ant
redis-cli -h $REDIS_HOST flushdb
cd ./hackathon_netty
ant
cd ..
export JAVA_ARGS="
-Xmx3200M 
-Xms3200M 
-Xmn2000M 
-XX:+UseConcMarkSweepGC 
-XX:+UseParNewGC 
-XX:+CMSParallelRemarkEnabled 
-XX:+UseCMSCompactAtFullCollection 
-XX:CMSFullGCsBeforeCompaction=0 
-XX:+CMSClassUnloadingEnabled
-XX:TargetSurvivorRatio=90
-XX:+TraceClassUnloading
"

export GC_ARGS="
-Xloggc:./gc.log 
-XX:+PrintGCDetails 
-XX:+PrintGCDateStamps"
cd ./hackathon_netty/out
java -jar -server $JAVA_ARGS $GC_ARGS ./hackathon.jar
