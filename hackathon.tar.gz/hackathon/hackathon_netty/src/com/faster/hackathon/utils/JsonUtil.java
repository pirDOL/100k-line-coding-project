/**
 * hzr
 * Copyright (c) 2004-2015 All Rights Reserved.
 */
package com.faster.hackathon.utils;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import io.netty.buffer.ByteBuf;
import io.netty.handler.codec.http.HttpContent;

/**
 * JsonUtil
 * 
 * @author hzr
 */
public class JsonUtil {

	public static String getJsonString(Object msg) throws UnsupportedEncodingException, IOException {
		HttpContent content = (HttpContent) msg;
		ByteBuf buf = content.content();
		String str = buf.toString(io.netty.util.CharsetUtil.UTF_8);
		buf.release();
		return str;
	}

	/**
	 * 
	 * @param arg
	 * @return
	 */
	public static Map getJsonMap(String... arg) {
		if (arg.length % 2 != 0) {
			return null;
		}
		Map map = new HashMap<String, String>();

		for (int i = 0; i < arg.length; i += 2) {
			map.put(arg[i], arg[i + 1]);
		}

		return map;
	}

	/**
	 * 
	 * @param arg
	 * @return
	 */
	public static JSONArray getItemJsonArray(String str) {
		String array[] = str.split(" ");

		JSONArray jsa = new JSONArray();

		for (int i = 0; i < array.length; i += 2) {
			JSONObject jso = new JSONObject();
			jso.put(ConstantsValue.FOOD_ID, Integer.valueOf(array[i]));
			jso.put(ConstantsValue.COUNT, Integer.valueOf(array[i + 1]));
			jsa.add(jso);
		}
		return jsa;
	}

	public boolean isValidJson(String jsonStr) {
		return !jsonStr.isEmpty() && jsonStr.charAt(0) == '{';
	}

	// {"food_id": 1, "count": 2}
	public static int[] parsePatchFood(String jsonStr) {
		int ans[] = new int[2];
		int start, end = 0, ansIndex;
		char ch;
		start = jsonStr.indexOf("\"", end);
		if (jsonStr.charAt(start + 1) == 'f')
			ansIndex = 0;
		else
			ansIndex = 1;

		for (int i = 0; i < 2; ++i) {
			start = jsonStr.indexOf(":", end);
			do {
				++start;
				ch = jsonStr.charAt(start);
			} while (start < jsonStr.length() && ch == ' ');

			end = start;
			do {
				++end;
				ch = jsonStr.charAt(end);
			} while (end < jsonStr.length() && (ch != ',' && ch != '}'));
			ans[ansIndex] = Integer.valueOf(jsonStr.substring(start, end));
			ansIndex = 1 - ansIndex;
		}
		return ans;
	}

	// {"username": "robot","password": "robot"}
	public static String[] parseLogin(String jsonStr) {
		String[] ans = new String[2];

		char ch;
		int end = 0;
		int start = jsonStr.indexOf(":");
		do {
			++start;
			ch = jsonStr.charAt(start);
		} while (start < jsonStr.length() && (ch == ' ' || ch == '\"'));

		end = jsonStr.indexOf(",", start);
		ans[0] = jsonStr.substring(start, end - 1);

		start = jsonStr.indexOf(":", end);
		do {
			++start;
			ch = jsonStr.charAt(start);
		} while (start < jsonStr.length() && (ch == ' ' || ch == '\"'));

		// int end = jsonStr.lastIndexOf("\"");
		end = jsonStr.length() - 2;
		ans[1] = jsonStr.substring(start, end);
		return ans;
	}

	// {"cart_id": "e0c68eb96bd8495dbb8fcd8e86fc48a3"}
	public static String parseCartId(String jsonStr) {
		int start = jsonStr.indexOf(":");
		char ch;
		do {
			++start;
			ch = jsonStr.charAt(start);
		} while (start < jsonStr.length() && (ch == ' ' || ch == '\"'));

		// int end = jsonStr.lastIndexOf("\"");
		int end = jsonStr.length() - 2;
		return jsonStr.substring(start, end);
	}
}
