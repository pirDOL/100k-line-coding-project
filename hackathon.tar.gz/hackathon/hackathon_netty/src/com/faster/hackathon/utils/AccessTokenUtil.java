/**
 * hzr
 * Copyright (c) 2004-2015 All Rights Reserved.
 */
package com.faster.hackathon.utils;

/**
 * 
 * @author hzr
 */
public class AccessTokenUtil {
	// public static String[] userIdToAccessToken = new
	// String[ConstantsValue.TOTAL_USER_COUNT + 10];

	public static void intClass() {
		// for (int i = 1; i <= ConstantsValue.TOTAL_USER_COUNT; i++) {
		// userIdToAccessToken[i] = ConstantsValue.ACCESS_TOKEN_PREFIX +
		// String.format("%05d", i);
		// }
	}

	public static boolean isValidToken(String accessToken) {
		if (accessToken.substring(0, ConstantsValue.PRE_BIT).equals(ConstantsValue.ACCESS_TOKEN_PREFIX)) {
			return true;
		}
		return false;
	}

	public static String getAccessToken(int userId) {
		String str = ConstantsValue.ACCESS_TOKEN_PREFIX + String.format("%011d", userId);
		str.intern();
		return str;
	}
}
