package com.faster.hackathon.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Scanner;

import com.alibaba.fastjson.JSONObject;
import com.faster.hackathon.redis.JedisUtil;
import com.faster.hackathon.utils.ConstantsValue;
import com.faster.hackathon.utils.JsonUtil;

import io.netty.handler.codec.http.FullHttpResponse;
import io.netty.handler.codec.http.HttpRequest;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.netty.handler.codec.http.QueryStringDecoder;

public class OrderHandler implements HttpRequestHandler {
	private ServiceEnum name = ServiceEnum.ORDER;
	private static String SHA_ORDER = "";

	static {
		InputStream in = OrderHandler.class.getClassLoader()
				.getResourceAsStream("com/faster/hackathon/resource/order.lua");
		try {
			Scanner scanner = new Scanner(in);
			String script = "";
			while (scanner.hasNext()) {
				script += scanner.nextLine() + " ";
			}
			in.close();
			SHA_ORDER = JedisUtil.getScriptLoadSha(script);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void init() {
		// TODO Auto-generated method stub

	}

	@Override
	public void doAction(Object msg, FullHttpResponse response) {
		// TODO Auto-generated method stub
		HttpRequest request = (HttpRequest) msg;
		String cartId = "";

		String accessToken;
		try {
			QueryStringDecoder queryStringDecoder = new QueryStringDecoder(request.uri());
			if (queryStringDecoder.parameters().containsKey(ConstantsValue.ACCESS_TOKEN)) {
				accessToken = queryStringDecoder.parameters().get(ConstantsValue.ACCESS_TOKEN).get(0);
			} else {
				accessToken = (String) request.headers().get(ConstantsValue.ACCESS_TOKEN_HEADER);
			}
			queryStringDecoder = null;

			if (accessToken == null || accessToken.isEmpty()) {
				processResponse(response, HttpResponseStatus.UNAUTHORIZED, ConstantsValue.CODE,
						ConstantsValue.INVALID_ACCESS_TOKEN, ConstantsValue.MESSAGE,
						ConstantsValue.MESSAGE_INVALID_TOKEN);
			} else {
				try {
					String acceptjson = JsonUtil.getJsonString(request);
					if (!acceptjson.isEmpty()) {
						JSONObject jb = JSONObject.parseObject(acceptjson);
						cartId = jb.getString(ConstantsValue.CART_ID);
						jb = null;
						// cartId = JsonUtil.parseCartId(acceptjson);
						// cartId = parseCartId(acceptjson);
						// 获取不到ACCESS_TOKEN，报“无权限访问指定的篮子”
						// if (AccessTokenUtil.isValidToken(accessToken)) {
						// processResponse(response, 401, ConstantsValue.CODE,
						// ConstantsValue.NOT_AUTHORIZED_TO_ACCESS_CART,
						// ConstantsValue.MESSAGE,
						// ConstantsValue.MESSAGE_NOT_AUTHORIZED_TO_ACCESS_CART);
						// return;
						// }

						// realCartId为空，报“篮子不存在”
						// if (!CartIdUtil.isValidCartId(cartId)) {
						// processResponse(response, 404, ConstantsValue.CODE,
						// ConstantsValue.CART_NOT_FOUND,
						// ConstantsValue.MESSAGE,
						// ConstantsValue.MESSAGE_CART_NOT_FOUND);
						// return;
						// }

						// 获cartId错误，报“无权限访问指定的篮子”
						// if (!realCartId.equals(cartId)) {
						// processResponse(response, 401, ConstantsValue.CODE,
						// ConstantsValue.NOT_AUTHORIZED_TO_ACCESS_CART,
						// ConstantsValue.MESSAGE,
						// ConstantsValue.MESSAGE_NOT_AUTHORIZED_TO_ACCESS_CART);
						// return;
						// }
						String userId = cartId.substring(ConstantsValue.PRE_BIT, 32);
						String orderKey = ConstantsValue.ORDER + ConstantsValue.KEY_SPILITTER + userId;
						// 每个用户只能下一单
						if (JedisUtil.exisitKey(orderKey)) {
							processResponse(response, HttpResponseStatus.FORBIDDEN, ConstantsValue.CODE,
									ConstantsValue.ORDER_OUT_OF_LIMIT, ConstantsValue.MESSAGE,
									ConstantsValue.MESSAGE_ORDER_OUT_OF_LIMIT);
							return;
						}

						// 下单
						long dataResult = JedisUtil.executeScript(SHA_ORDER, 1,
								ConstantsValue.ORDER + ConstantsValue.KEY_SPILITTER + userId, userId);

						if (dataResult == 0) {
							response.setStatus(HttpResponseStatus.OK);

							Map<String, String> mapOrderValue = JedisUtil.getMapValue(orderKey);
							String orderId = mapOrderValue.get(ConstantsValue.ORDER_ID);
							String jsonStr = "{\"" + ConstantsValue.ID + "\":\"" + orderId + "\"}";
							response.content().writeBytes(jsonStr.getBytes());
							return;
						}
						// else if (dataResult == 4) {
						// processResponse(response, 403, ConstantsValue.CODE,
						// ConstantsValue.FOOD_OUT_OF_LIMIT,
						// ConstantsValue.MESSAGE,
						// ConstantsValue.MESSAGE_FOOD_OUT_OF_LIMIT);
						// return;
						// }
						else if (dataResult == 5) {
							// 食物库存不足
							processResponse(response, HttpResponseStatus.FORBIDDEN, ConstantsValue.CODE,
									ConstantsValue.FOOD_OUT_OF_STOCK, ConstantsValue.MESSAGE,
									ConstantsValue.MESSAGE_FOOD_OUT_OF_STOCK);
							return;
						}

					} else {
						response.setStatus(HttpResponseStatus.NO_CONTENT);

					}
				} catch (Exception e) {

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void processResponse(FullHttpResponse response, HttpResponseStatus responseCode, String msgName1,
			String msgContent1, String msgName2, String msgContent2) throws IOException {
		response.setStatus(responseCode);

		JSONObject jso = new JSONObject();
		jso.put(msgName1, msgContent1);
		jso.put(msgName2, msgContent2);

		response.content().writeBytes(jso.toString().getBytes());
		jso = null;
	}

	@Override
	public void setName(ServiceEnum serviceName) {
		// TODO Auto-generated method stub

	}

	@Override
	public ServiceEnum getName() {
		// TODO Auto-generated method stub
		return null;
	}

}
