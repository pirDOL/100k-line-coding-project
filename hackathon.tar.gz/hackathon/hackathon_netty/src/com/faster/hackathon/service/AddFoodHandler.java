package com.faster.hackathon.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;

import com.alibaba.fastjson.JSONObject;
import com.faster.hackathon.redis.JedisUtil;
import com.faster.hackathon.utils.CartIdUtil;
import com.faster.hackathon.utils.ConstantsValue;
import com.faster.hackathon.utils.JsonUtil;

import io.netty.handler.codec.http.FullHttpResponse;
import io.netty.handler.codec.http.HttpRequest;
import io.netty.handler.codec.http.HttpResponseStatus;

public class AddFoodHandler implements HttpRequestHandler {
	private ServiceEnum name = ServiceEnum.ADD_FOOD;
	private static String SHA_PATCH = "";

	static {
		InputStream in = AddFoodHandler.class.getClassLoader()
				.getResourceAsStream("com/faster/hackathon/resource/patch.lua");
		try {
			Scanner scanner = new Scanner(in);
			String script = "";
			while (scanner.hasNext()) {
				script += scanner.nextLine() + " ";
			}
			in.close();
			SHA_PATCH = JedisUtil.getScriptLoadSha(script);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void init() {
		// TODO Auto-generated method stub

	}

	@Override
	public void doAction(Object msg, FullHttpResponse response) {
		// TODO Auto-generated method stub
		try {
			HttpRequest request = (HttpRequest) msg;

			String uriStr = request.uri();
			int index1 = uriStr.lastIndexOf('/');
			int index2 = uriStr.indexOf('?');
			String cartId;
			if (index2 > 0) {
				cartId = uriStr.substring(index1 + 1, index2);
			} else {
				cartId = uriStr.substring(index1 + 1, uriStr.length());
			}
			String accessToken;
			if (index2 > 0) {
				int index3 = uriStr.indexOf('=');
				accessToken = uriStr.substring(index3 + 1, uriStr.length());
			}
			// URI uri = new URI(request.uri());
			// String[] strs = uri.getPath().split("/");
			// String cartId = strs[2];
			//
			// QueryStringDecoder queryStringDecoder = new
			// QueryStringDecoder(request.uri());
			// String accessToken;
			// if
			// (queryStringDecoder.parameters().containsKey(ConstantsValue.ACCESS_TOKEN))
			// {
			// accessToken =
			// queryStringDecoder.parameters().get(ConstantsValue.ACCESS_TOKEN).get(0);
			// }
			else {
				accessToken = (String) request.headers().get(ConstantsValue.ACCESS_TOKEN_HEADER);
			}
			if (accessToken == null || accessToken.isEmpty()) {
				try {
					processResponse(response, HttpResponseStatus.UNAUTHORIZED, ConstantsValue.CODE,
							ConstantsValue.INVALID_ACCESS_TOKEN, ConstantsValue.MESSAGE,
							ConstantsValue.MESSAGE_INVALID_TOKEN);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else {
				try {
					String acceptjson = JsonUtil.getJsonString(request);
					if (!acceptjson.isEmpty()) {
						JSONObject jb = JSONObject.parseObject(acceptjson);
						// int[] jsonArr = JsonUtil.parsePatchFood(acceptjson);
						int foodId = jb.getInteger(ConstantsValue.FOOD_ID);
						// int foodId = jsonArr[0];
						// jsonArr[1]);
						if (foodId <= 0) {
							processResponse(response, HttpResponseStatus.NOT_FOUND, ConstantsValue.CODE,
									ConstantsValue.FOOD_NOT_FOUND, ConstantsValue.MESSAGE,
									ConstantsValue.MESSAGE_FOOD_NOT_FOUND);
							return;
						}

						int count = jb.getInteger(ConstantsValue.COUNT);
						jb = null;
						// int count = jsonArr[1];
						// if (count > 3 || count < -3) {
						// processResponse(response, 403, ConstantsValue.CODE,
						// ConstantsValue.FOOD_OUT_OF_LIMIT,
						// ConstantsValue.MESSAGE,
						// ConstantsValue.MESSAGE_FOOD_OUT_OF_LIMIT);
						// return;
						// }

						// 获取不到ACCESS_TOKEN，报“无权限访问指定的篮子”
						// if (AccessTokenUtil.isValidToken(accessToken)) {
						// processResponse(response, 401, ConstantsValue.CODE,
						// ConstantsValue.NOT_AUTHORIZED_TO_ACCESS_CART,
						// ConstantsValue.MESSAGE,
						// ConstantsValue.MESSAGE_NOT_AUTHORIZED_TO_ACCESS_CART);
						// return;
						// }

						String userId = accessToken.substring(ConstantsValue.PRE_BIT, 32);
						// 获cartId错误，报“篮子不存在”
						if (!CartIdUtil.isValidCartId(cartId)) {
							processResponse(response, HttpResponseStatus.NOT_FOUND, ConstantsValue.CODE,
									ConstantsValue.CART_NOT_FOUND, ConstantsValue.MESSAGE,
									ConstantsValue.MESSAGE_CART_NOT_FOUND);
							return;
						}

						// 添加食物
						long dataResult = JedisUtil.executeScript(SHA_PATCH, 1,
								ConstantsValue.CART + ConstantsValue.KEY_SPILITTER + userId, String.valueOf(foodId),
								String.valueOf(count), userId);

						if (dataResult == 0) {
							response.setStatus(HttpResponseStatus.NO_CONTENT);
							return;
						} else if (dataResult == 4) {
							processResponse(response, HttpResponseStatus.FORBIDDEN, ConstantsValue.CODE,
									ConstantsValue.FOOD_OUT_OF_LIMIT, ConstantsValue.MESSAGE,
									ConstantsValue.MESSAGE_FOOD_OUT_OF_LIMIT);
							return;
						}

					} else {
						response.setStatus(HttpResponseStatus.NO_CONTENT);
					}
				} catch (Exception e) {

				}
			}
		} catch (

		Exception e)

		{
			e.printStackTrace();
		}

	}

	private void processResponse(FullHttpResponse response, HttpResponseStatus responseCode, String msgName1,
			String msgContent1, String msgName2, String msgContent2) throws IOException {
		response.setStatus(responseCode);

		JSONObject jso = new JSONObject();
		jso.put(msgName1, msgContent1);
		jso.put(msgName2, msgContent2);

		response.content().writeBytes(jso.toString().getBytes());
		jso = null;
	}

	@Override
	public void setName(ServiceEnum serviceName) {
		// TODO Auto-generated method stub
		this.name = serviceName;
	}

	@Override
	public ServiceEnum getName() {
		// TODO Auto-generated method stub
		return name;
	}

}
