package com.faster.hackathon.service;

import java.util.Map;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSONObject;
import com.faster.hackathon.dao.impl.UserDaoImpl;
import com.faster.hackathon.entities.User;
import com.faster.hackathon.redis.JedisUtil;
import com.faster.hackathon.utils.AccessTokenUtil;
import com.faster.hackathon.utils.ConstantsValue;
import com.faster.hackathon.utils.JsonUtil;

import io.netty.handler.codec.http.FullHttpResponse;
import io.netty.handler.codec.http.HttpRequest;
import io.netty.handler.codec.http.HttpResponseStatus;

public class LoginHandler implements HttpRequestHandler {

	private ServiceEnum name = ServiceEnum.LOGIN;
	private static String USER_AUTH_FAIL_STRING = "{\"code\": \"USER_AUTH_FAIL\",\"message\": \"用户名或密码错误\"}";
	private static String EMPTY_REQUEST_JSON_STRING = "{\"code\": \"EMPTY_REQUEST\",\"message\": \"请求体为空\"}";
	private static String MALFORMED_JSON_STRING = "{\"code\": \"MALFORMED_JSON\",\"message\": \"格式错误\"}";

	private static Logger logger = Logger.getLogger(LoginHandler.class);

	@Override
	public void init() {
		// TODO Auto-generated method stub

	}

	@Override
	public void doAction(Object msg, FullHttpResponse response) {
		// TODO Auto-generated method stub
		logger.debug("login start");
		try {
			String acceptjson = JsonUtil.getJsonString(msg);
			HttpRequest request = (HttpRequest) msg;
			if (!acceptjson.isEmpty()) {
				JSONObject jb = JSONObject.parseObject(acceptjson);

				String username = jb.get("username").toString();
				String password = jb.getString("password").toString();
				jb = null;
				// String[] jsonArr = JsonUtil.parseLogin(acceptjson);
				// String username = jsonArr[0];
				// String password = jsonArr[1];

				String realPassord = null;
				String accessToken = null;
				int userId = 0;
				String key = "user:" + username + ":" + password;

				String queryPassword = null;

				// 先从缓存中查
				User user = UserDaoImpl.userMap.get(username);

				// 再从redis中查
				if (user == null) {
					Map<String, String> cachedUser = JedisUtil.getMapValue(key);
					if (cachedUser != null && !cachedUser.isEmpty()) {
						queryPassword = password;
						userId = Integer.valueOf(cachedUser.get(ConstantsValue.USER_ID));
					}

				} else {
					queryPassword = user.getPassword();
					userId = user.getId();
				}

				user = null;

				if (queryPassword == null || !queryPassword.equals(password)) {
					response.setStatus(HttpResponseStatus.FORBIDDEN);
					response.content().writeBytes(USER_AUTH_FAIL_STRING.getBytes());
					return;
				}

				accessToken = AccessTokenUtil.getAccessToken(userId);

				// POST /login
				// {
				// "user_id": 1,
				// "username": "robot",
				// "access_token": "xxx"
				// }
				String jsoStr = String.format("{\"user_id\":%d,\"username\": \"%s\",\"access_token\": \"%s\"}", userId,
						username, accessToken);

				response.content().writeBytes(jsoStr.getBytes());

			} else {
				response.setStatus(HttpResponseStatus.BAD_REQUEST);
				response.content().writeBytes(EMPTY_REQUEST_JSON_STRING.getBytes());
			}

		} catch (Exception e) {
			e.printStackTrace();
			response.setStatus(HttpResponseStatus.BAD_REQUEST);
			response.content().writeBytes(MALFORMED_JSON_STRING.getBytes());
		}
	}

	@Override
	public void setName(ServiceEnum serviceName) {
		// TODO Auto-generated method stub
		this.name = serviceName;
	}

	@Override
	public ServiceEnum getName() {
		// TODO Auto-generated method stub
		return name;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LoginHandler other = (LoginHandler) obj;
		if (name != other.name)
			return false;
		return true;
	}

}
