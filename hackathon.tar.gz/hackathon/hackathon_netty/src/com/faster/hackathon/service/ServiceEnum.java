package com.faster.hackathon.service;

public enum ServiceEnum {
	LOGIN, CREATE_CART, ADD_FOOD, QUERY_FOODS, ADMIN_ORDERS, ORDER, QUERY_ORDER
}
