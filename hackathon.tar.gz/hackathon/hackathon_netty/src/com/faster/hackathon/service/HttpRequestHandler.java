package com.faster.hackathon.service;

import io.netty.handler.codec.http.FullHttpResponse;

public interface HttpRequestHandler {
	public void init();

	public void doAction(Object msg, FullHttpResponse response);

	public void setName(ServiceEnum serviceName);

	public ServiceEnum getName();
}
