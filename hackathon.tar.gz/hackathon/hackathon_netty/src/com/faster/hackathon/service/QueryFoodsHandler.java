package com.faster.hackathon.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.alibaba.fastjson.JSON;
import com.faster.hackathon.dao.impl.FoodDaoImpl;
import com.faster.hackathon.entities.Food;
import com.faster.hackathon.redis.JedisUtil;
import com.faster.hackathon.utils.AccessTokenUtil;
import com.faster.hackathon.utils.ConstantsValue;
import com.faster.hackathon.utils.JsonUtil;

import io.netty.handler.codec.http.FullHttpResponse;
import io.netty.handler.codec.http.HttpRequest;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.netty.handler.codec.http.QueryStringDecoder;

public class QueryFoodsHandler implements HttpRequestHandler {
	private ServiceEnum name = ServiceEnum.QUERY_FOODS;

	@Override
	public void init() {
		// TODO Auto-generated method stub

	}

	@Override
	public void doAction(Object msg, FullHttpResponse response) {
		// TODO Auto-generated method stub
		try {
			HttpRequest request = (HttpRequest) msg;
			String accessToken;
			QueryStringDecoder queryStringDecoder = new QueryStringDecoder(request.uri());
			if (queryStringDecoder.parameters().containsKey(ConstantsValue.ACCESS_TOKEN)) {
				accessToken = queryStringDecoder.parameters().get(ConstantsValue.ACCESS_TOKEN).get(0);
			} else {
				accessToken = (String) request.headers().get(ConstantsValue.ACCESS_TOKEN_HEADER);
			}

			if (accessToken == null || accessToken.isEmpty()) {
				processInvalidAccessToken(response);
			} else {
				if (AccessTokenUtil.isValidToken(accessToken)) {
					// StringBuilder strBuilder = new StringBuilder(4000);
					// List<Food> listFood = getAllFoods();
					// // JSONArray jsa = JSONArray.fromObject(listFood);
					// strBuilder.append("[");
					// for (int i = 0; i < listFood.size() - 1; i++) {
					// Food food = listFood.get(i);
					// strBuilder.append("{\"id\":" + food.getId() +
					// ",\"price\":" + food.getPrice() + ",\"stock\":"
					// + food.getStock() + "},");
					// }
					// Food food = listFood.get(listFood.size() - 1);
					// strBuilder.append("{\"id\":" + food.getId() +
					// ",\"price\":" + food.getPrice() + ",\"stock\":"
					// + food.getStock() + "}]");
					// response.content().writeBytes(strBuilder.toString().getBytes());
					// listFood = null;

					response.content().writeBytes(FoodDaoImpl.foodListJson.getBytes());
				} else {
					processInvalidAccessToken(response);
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	private void processInvalidAccessToken(FullHttpResponse response) throws IOException {
		response.setStatus(HttpResponseStatus.UNAUTHORIZED);

		String str = JSON.toJSONString(JsonUtil.getJsonMap("code", "INVALID_ACCESS_TOKEN", "message", "无效的令牌"));

		response.content().writeBytes(str.getBytes());
	}

	private List<Food> getAllFoods() {
		List<String> priceKeyList = new ArrayList<String>(110);
		List<String> stockKeyList = new ArrayList<String>(110);
		List<Food> foodList = new ArrayList<Food>();

		for (int i = 1; i <= 100; i++) {
			priceKeyList.add("price:" + i);
			stockKeyList.add("stock:" + i);
		}

		String[] priceKeyArr = new String[priceKeyList.size()];
		String[] stockKeyArr = new String[stockKeyList.size()];
		priceKeyList.toArray(priceKeyArr);
		stockKeyList.toArray(stockKeyArr);
		List<String> priceValueList = JedisUtil.mgetStringValue(priceKeyArr);
		List<String> stockValueList = JedisUtil.mgetStringValue(stockKeyArr);

		for (int i = 0; i < 100; i++) {
			Food food = new Food(i + 1, Integer.valueOf(stockValueList.get(i)), Integer.valueOf(priceValueList.get(i)));
			foodList.add(food);
		}
		return foodList;

	}

	@Override
	public void setName(ServiceEnum serviceName) {
		// TODO Auto-generated method stub
		this.name = serviceName;
	}

	@Override
	public ServiceEnum getName() {
		// TODO Auto-generated method stub
		return name;
	}

}
