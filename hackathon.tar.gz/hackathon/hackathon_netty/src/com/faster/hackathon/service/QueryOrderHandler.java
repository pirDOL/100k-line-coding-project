package com.faster.hackathon.service;

import java.io.IOException;
import java.util.Map;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.faster.hackathon.redis.JedisUtil;
import com.faster.hackathon.utils.AccessTokenUtil;
import com.faster.hackathon.utils.ConstantsValue;
import com.faster.hackathon.utils.JsonUtil;

import io.netty.handler.codec.http.FullHttpResponse;
import io.netty.handler.codec.http.HttpRequest;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.netty.handler.codec.http.QueryStringDecoder;

public class QueryOrderHandler implements HttpRequestHandler {
	private ServiceEnum name = ServiceEnum.QUERY_ORDER;

	@Override
	public void init() {
		// TODO Auto-generated method stub

	}

	@Override
	public void doAction(Object msg, FullHttpResponse response) {
		// TODO Auto-generated method stub
		HttpRequest request = (HttpRequest) msg;
		String accessToken;
		try {
			QueryStringDecoder queryStringDecoder = new QueryStringDecoder(request.uri());
			if (queryStringDecoder.parameters().containsKey(ConstantsValue.ACCESS_TOKEN)) {
				accessToken = queryStringDecoder.parameters().get(ConstantsValue.ACCESS_TOKEN).get(0);
			} else {
				accessToken = (String) request.headers().get(ConstantsValue.ACCESS_TOKEN_HEADER);
			}
			if (accessToken == null || accessToken.isEmpty()) {
				processResponse(response, HttpResponseStatus.UNAUTHORIZED, ConstantsValue.CODE,
						ConstantsValue.INVALID_ACCESS_TOKEN, ConstantsValue.MESSAGE,
						ConstantsValue.MESSAGE_INVALID_TOKEN);
			} else {
				if (AccessTokenUtil.isValidToken(accessToken)) {
					String userId = accessToken.substring(ConstantsValue.PRE_BIT, 32);

					String orderKey = ConstantsValue.ORDER + ":" + userId;
					Map<String, String> orderMapValue = JedisUtil.getMapValue(orderKey);

					// order:<access_token>不存在，getMapValue返回不是null，而是orderMapValue为空
					if (orderMapValue == null || orderMapValue.isEmpty()) {
						// JSONArray jsa = new JSONArray();
						response.content().writeBytes("[]".getBytes());
						return;
					}

					String orderId = orderMapValue.get(ConstantsValue.ORDER_ID);
					String items = orderMapValue.get(ConstantsValue.ITEMS);
					String total = orderMapValue.get(ConstantsValue.TOTAL);

					orderMapValue = null;

					JSONObject jso = new JSONObject();
					jso.put(ConstantsValue.ORDER_ID, orderId);
					jso.put(ConstantsValue.ITEMS, JsonUtil.getItemJsonArray(items));
					jso.put(ConstantsValue.TOTAL, Integer.valueOf(total));

					JSONArray ja = new JSONArray();
					ja.add(jso);
					String str = JSON.toJSONString(ja);
					response.content().writeBytes(str.getBytes());
				} else {
					processResponse(response, HttpResponseStatus.UNAUTHORIZED, ConstantsValue.CODE,
							ConstantsValue.INVALID_ACCESS_TOKEN, ConstantsValue.MESSAGE,
							ConstantsValue.MESSAGE_INVALID_TOKEN);
				}
			}
		} catch (Exception e) {

		}
	}

	private void processResponse(FullHttpResponse response, HttpResponseStatus responseCode, String msgName1,
			String msgContent1, String msgName2, String msgContent2) throws IOException {
		response.setStatus(responseCode);

		JSONObject jso = new JSONObject();
		jso.put(msgName1, msgContent1);
		jso.put(msgName2, msgContent2);

		response.content().writeBytes(jso.toString().getBytes());
		jso = null;
	}

	@Override
	public void setName(ServiceEnum serviceName) {
		// TODO Auto-generated method stub
		this.name = serviceName;
	}

	@Override
	public ServiceEnum getName() {
		// TODO Auto-generated method stub
		return name;
	}

}
