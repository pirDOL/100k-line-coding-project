package com.faster.hackathon.service;

import java.io.IOException;

import com.alibaba.fastjson.JSONObject;
import com.faster.hackathon.utils.AccessTokenUtil;
import com.faster.hackathon.utils.ConstantsValue;

import io.netty.handler.codec.http.FullHttpResponse;
import io.netty.handler.codec.http.HttpRequest;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.netty.handler.codec.http.QueryStringDecoder;

public class CreateCartHandler implements HttpRequestHandler {
	private ServiceEnum name = ServiceEnum.CREATE_CART;

	@Override
	public void init() {
		// TODO Auto-generated method stub

	}

	@Override
	public void doAction(Object msg, FullHttpResponse response) {
		// TODO Auto-generated method stub
		try {
			HttpRequest request = (HttpRequest) msg;

			QueryStringDecoder queryStringDecoder = new QueryStringDecoder(request.uri());
			String accessToken;
			if (queryStringDecoder.parameters().containsKey(ConstantsValue.ACCESS_TOKEN)) {
				accessToken = queryStringDecoder.parameters().get(ConstantsValue.ACCESS_TOKEN).get(0);
			} else {
				accessToken = (String) request.headers().get(ConstantsValue.ACCESS_TOKEN_HEADER);
			}

			queryStringDecoder = null;

			if (accessToken == null || accessToken.isEmpty()) {
				processResponse(response, HttpResponseStatus.UNAUTHORIZED, ConstantsValue.CODE,
						ConstantsValue.INVALID_ACCESS_TOKEN, ConstantsValue.MESSAGE,
						ConstantsValue.MESSAGE_INVALID_TOKEN);
			} else {
				if (AccessTokenUtil.isValidToken(accessToken)) {
					String cartId = ConstantsValue.CART_ID_PREFIX + accessToken.substring(ConstantsValue.PRE_BIT, 32);
					// JSONObject jso = new JSONObject();
					// jso.put(ConstantsValue.CART_ID, cartId);
					String jsonStr = "{\"" + ConstantsValue.CART_ID + "\":\"" + cartId + "\"}";
					response.content().writeBytes(jsonStr.getBytes());
					// jso = null;

				} else {
					processResponse(response, HttpResponseStatus.UNAUTHORIZED, ConstantsValue.CODE,
							ConstantsValue.INVALID_ACCESS_TOKEN, ConstantsValue.MESSAGE,
							ConstantsValue.MESSAGE_INVALID_TOKEN);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void processResponse(FullHttpResponse response, HttpResponseStatus responseCode, String msgName1,
			String msgContent1, String msgName2, String msgContent2) throws IOException {
		response.setStatus(responseCode);

		JSONObject jso = new JSONObject();
		jso.put(msgName1, msgContent1);
		jso.put(msgName2, msgContent2);

		response.content().writeBytes(jso.toString().getBytes());
		jso = null;
	}

	@Override
	public void setName(ServiceEnum serviceName) {
		// TODO Auto-generated method stub
		this.name = serviceName;
	}

	@Override
	public ServiceEnum getName() {
		// TODO Auto-generated method stub
		return name;
	}

}
