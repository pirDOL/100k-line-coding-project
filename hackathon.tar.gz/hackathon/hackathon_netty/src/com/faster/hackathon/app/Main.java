package com.faster.hackathon.app;

import org.apache.log4j.PropertyConfigurator;

import com.faster.hackathon.server.NettyHttpServer;
import com.faster.hackathon.utils.AccessTokenUtil;
import com.faster.hackathon.utils.EnvDataUtil;

public class Main {
	public static void main(String[] args) {
		PropertyConfigurator.configure(
				Main.class.getClassLoader().getResourceAsStream("com/faster/hackathon/resource/log4j.properties"));
		EnvDataUtil.init();
		AccessTokenUtil.intClass();
		NettyHttpServer nettyHttpServer = new NettyHttpServer();
		System.gc();
		try {
			nettyHttpServer.start(EnvDataUtil.APP_HOST, EnvDataUtil.APP_PORT);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
