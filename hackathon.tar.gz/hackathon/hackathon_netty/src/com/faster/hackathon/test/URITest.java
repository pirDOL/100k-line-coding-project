package com.faster.hackathon.test;

import java.net.URI;
import java.net.URISyntaxException;

import org.junit.Test;

import com.faster.hackathon.utils.ConstantsValue;

import io.netty.handler.codec.http.QueryStringDecoder;

public class URITest {

	@Test
	public void testUri() throws URISyntaxException {
		URI uri = new URI("/carts/asdfasdf");
		System.out.println(uri.getRawPath());
		String[] strs = uri.toString().split("/");
		System.out.println(strs[1] + "," + strs[2]);

		String uriStr = ("/carts/asdfasdf?token=11111");
		int index1 = uriStr.lastIndexOf('/');
		int index2 = uriStr.indexOf('?');
		String cartId;
		if (index2 > 0) {
			cartId = uriStr.substring(index1 + 1, index2);
		} else {
			cartId = uriStr.substring(index1 + 1, uriStr.length());
		}
		System.out.println(cartId);
		int index3 = uriStr.indexOf('=');
		String token = uriStr.substring(index3 + 1, uriStr.length());
		System.out.println(token);

	}

	@Test
	public void testParam() {
		QueryStringDecoder queryStringDecoder = new QueryStringDecoder(
				"/carts?access_token=FE901E1WE33129FE81L9000000000001");
		if (queryStringDecoder.parameters().containsKey(ConstantsValue.ACCESS_TOKEN)) {
			String accessToken = queryStringDecoder.parameters().get(ConstantsValue.ACCESS_TOKEN).get(0);
			System.out.println(accessToken);
		}
	}
}
