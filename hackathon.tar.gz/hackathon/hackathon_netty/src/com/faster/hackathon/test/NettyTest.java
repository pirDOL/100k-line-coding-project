package com.faster.hackathon.test;

import org.junit.Test;

import com.faster.hackathon.server.NettyHttpServer;

public class NettyTest {
	@Test
	public void testStartNetty() {
		NettyHttpServer nettyHttpServer = new NettyHttpServer();
		try {
			nettyHttpServer.start("localhost", 8080);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
