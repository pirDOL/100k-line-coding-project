package com.faster.hackathon.test;

import org.junit.Test;

import com.faster.hackathon.utils.AccessTokenUtil;

public class AccessTokenTest {
	@Test
	public void test() {
		AccessTokenUtil.intClass();
		System.out.println(AccessTokenUtil.getAccessToken(1));
		System.out.println(AccessTokenUtil.getAccessToken(11));
		System.out.println(AccessTokenUtil.getAccessToken(126));
		System.out.println(AccessTokenUtil.getAccessToken(1000));

	}
}
