local count = tonumber(ARGV[2])
local nCounts = redis.call('HGET', KEYS[1], 'nCounts')
if nCounts == false or nCounts == '0' then
	if count <= 0 then
		return 0
	elseif count <= 3 then
		redis.call('SADD', 'items:' .. ARGV[3], ARGV[1])
		redis.call('HMSET', KEYS[1], 'nCounts', count, ARGV[1], count)
		return 0
	else
		return 4
	end
end

nCounts = nCounts + count
local curCount = redis.call('HGET', KEYS[1], ARGV[1])
if curCount == false or curCount == '0' then
	if count < 0 then
		return 0
	elseif nCounts <= 3 then
		redis.call('SADD', 'items:' .. ARGV[3], ARGV[1])
        redis.call('HMSET', KEYS[1], 'nCounts', nCounts, ARGV[1], count)
        return 0
	end
end

if nCounts > 3 or nCounts < 0 then
    return 4
end
curCount = curCount + count
if curCount < 0 then
    return 4
end

if curCount == 0 then
	redis.call('SREM', 'items:' .. ARGV[3], ARGV[1])
end
redis.call('HMSET', KEYS[1], 'nCounts', nCounts, ARGV[1], curCount)
return 0
