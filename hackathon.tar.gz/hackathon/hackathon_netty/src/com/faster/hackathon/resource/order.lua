local food_ids = redis.call('SMEMBERS', 'items:' .. ARGV[1])
if food_ids == false then
	return 4
end

local nOutofStock = #food_ids
local stocks, counts = {}, {}

for i, food_id in ipairs(food_ids) do
	counts[food_id] = tonumber(redis.call('HGET', 'cart:' .. ARGV[1], food_id))
	stocks[food_id] = tonumber(redis.call('GET', 'stock:' .. food_id)) - counts[food_id]
	if stocks[food_id] >= 0 then
		nOutofStock = nOutofStock - 1
	else
		break
	end
end

if nOutofStock ~= 0 then
	return 5 
end

local total = 0
local items = ''
for i, food_id in ipairs(food_ids) do
	redis.call('SET', 'stock:' .. food_id, stocks[food_id])
	total = total + tonumber(redis.call('GET', 'price:' .. food_id)) * counts[food_id]
	items = items .. food_id .. ' ' .. counts[food_id] .. ' '
end

redis.call('DEL', 'items:' .. ARGV[1])
local order_id = redis.call('INCR', 'order_id')
redis.call('HMSET', KEYS[1], 'total', total, 'items', items, 'id', order_id)
redis.call('LPUSH', 'orders', ARGV[1])
return 0
