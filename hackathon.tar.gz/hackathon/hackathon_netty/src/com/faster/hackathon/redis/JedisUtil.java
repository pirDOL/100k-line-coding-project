/**
 * hzr
 * Copyright (c) 2004-2015 All Rights Reserved.
 */
package com.faster.hackathon.redis;

import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.faster.hackathon.dao.FoodDao;
import com.faster.hackathon.dao.UserDao;
import com.faster.hackathon.dao.impl.FoodDaoImpl;
import com.faster.hackathon.dao.impl.UserDaoImpl;
import com.faster.hackathon.entities.Food;
import com.faster.hackathon.entities.User;
import com.faster.hackathon.utils.ConstantsValue;
import com.faster.hackathon.utils.EnvDataUtil;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.Pipeline;

/**
 * @author hfy
 *
 */
public class JedisUtil {
	private static JedisPool pool;

	public static JedisPool getPool() {
		return pool;
	}

	private static final String BOOT_KEY = "BOOTKEY";

	private final static String BOOT_UUID = java.util.UUID.randomUUID().toString().replace("-", "");

	private static final int EXPIRED_TIME = 60 * 5;
	private static final long TOKEN_OWNER = 1;

	static {
		InputStream is = JedisUtil.class.getClassLoader()
				.getResourceAsStream("com/faster/hackathon/resource/jedis.properties");
		Properties props = new Properties();

		props = new Properties();

		if (is == null) {
			System.out.println("is is null");

		}

		try {
			props.load(is);
			JedisPoolConfig config = new JedisPoolConfig();
			config.setMaxActive(Integer.valueOf(props.getProperty("redis.pool.maxActive").trim()));
			config.setMaxIdle(Integer.valueOf(props.getProperty("redis.pool.maxIdle").trim()));
			config.setMaxWait(Long.valueOf(props.getProperty("redis.pool.maxWait").trim()));
			config.setTestOnBorrow(Boolean.valueOf(props.getProperty("redis.pool.testOnBorrow").trim()));
			config.setTestOnReturn(Boolean.valueOf(props.getProperty("redis.pool.testOnReturn").trim()));
			pool = new JedisPool(config, EnvDataUtil.REDIS_HOST.trim(), EnvDataUtil.REDIS_PORT);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	static {

		System.out.println("init redis data");
		Jedis jedis = null;
		try {
			jedis = getResource();
			UserDao userDao = new UserDaoImpl();
			List<User> userList = userDao.getAllUsers();
			Map<String, User> mapUser = new HashMap<String, User>(180);
			for (User user : userList) {
				// Map<String, String> map = new HashMap<String, String>();
				// map.put(ConstantsValue.USER_ID,
				// String.valueOf(user.getId()));
				// map.put(ConstantsValue.PASSWORD, user.getPassword());
				// p.hmset(ConstantsValue.USER +
				// ConstantsValue.KEY_SPILITTER + user.getName(), map);
				mapUser.put(user.getName(), user);
			}
			userDao.setUserMap(mapUser);
			long response = jedis.setnx(BOOT_KEY, BOOT_UUID);
			if (response == 1) {
				// System.err.println("BOOT_UUID " + BOOT_UUID + " get the
				// owner");
				jedis.expire(BOOT_KEY, EXPIRED_TIME);
				// TODO: init jedis data

				Pipeline p = jedis.pipelined();

				FoodDao foodDao = new FoodDaoImpl();
				List<Food> foodList = foodDao.getAllFoods();

				FoodDaoImpl.foodList = foodList;

				JSONArray ja = new JSONArray();

				for (Food food : foodList) {
					p.set("price:" + food.getId(), String.valueOf(food.getPrice()));
					p.set("stock:" + food.getId(), String.valueOf(food.getStock()));
					JSONObject js = new JSONObject();
					js.put("id", food.getId());
					js.put("price", food.getPrice());
					js.put("stock", food.getStock());
					ja.add(js);
				}
				FoodDaoImpl.foodListJson = ja.toJSONString();
				for (User user : userList) {
					Map<String, String> map = new HashMap<String, String>(2);
					map.put(ConstantsValue.USER_ID, String.valueOf(user.getId()));
					p.hmset(ConstantsValue.USER + ConstantsValue.KEY_SPILITTER + user.getPassword(), map);
				}
				p.sync();

			}
			System.out.println("init redis data end");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.returnResource(jedis);
		}
	}

	public static Jedis getResource() {
		return pool.getResource();
	}

	public static boolean exisitKey(String key) {
		Jedis jedis = null;
		try {
			jedis = getResource();
			return jedis.exists(key);
		} catch (Exception e) {
			pool.returnBrokenResource(jedis);
			e.printStackTrace();
			return false;
		} finally {
			pool.returnResource(jedis);
		}
	}

	/**
	 * 
	 * @param key
	 * @param stringValue
	 */
	public static int setStringValue(String key, String stringValue) {
		Jedis jedis = null;
		try {
			jedis = getResource();
			jedis.set(key, stringValue);
			return 0;
		} catch (Exception e) {
			pool.returnBrokenResource(jedis);
			e.printStackTrace();
			return -1;
		} finally {
			pool.returnResource(jedis);
		}
	}

	public static String getStringValue(String key) {
		Jedis jedis = null;
		try {
			jedis = getResource();
			return jedis.get(key);
		} catch (Exception e) {
			pool.returnBrokenResource(jedis);
			e.printStackTrace();
			return null;
		} finally {
			pool.returnResource(jedis);
		}

	}

	public static int setMapValue(String key, Map<String, String> mapValue) {
		Jedis jedis = null;
		try {
			jedis = getResource();
			jedis.hmset(key, mapValue);
			return 0;
		} catch (Exception e) {
			pool.returnBrokenResource(jedis);
			e.printStackTrace();
			return -1;
		} finally {
			pool.returnResource(jedis);
		}

	}

	public static Map<String, String> getMapValue(String key) {
		Jedis jedis = null;
		try {
			jedis = getResource();
			return jedis.hgetAll(key);

		} catch (Exception e) {
			pool.returnBrokenResource(jedis);
			e.printStackTrace();
			return null;

		} finally {
			pool.returnResource(jedis);
		}
	}

	/**
	 * @param key
	 * @param listValue
	 * @return
	 */
	public static int setListValue(String key, List<String> listValue) {
		Jedis jedis = null;
		try {
			jedis = getResource();

			for (String str : listValue) {
				jedis.lpush(key, str);
			}
			return 0;
		} catch (Exception e) {
			pool.returnBrokenResource(jedis);
			e.printStackTrace();
			return -1;
		} finally {
			pool.returnResource(jedis);
		}
	}

	public static List<String> getListValue(String key) {
		Jedis jedis = null;
		try {
			jedis = getResource();
			return jedis.lrange(key, 0, -1);

		} catch (Exception e) {
			pool.returnBrokenResource(jedis);
			e.printStackTrace();
			return null;

		} finally {
			pool.returnResource(jedis);
		}
	}

	/**
	 * 
	 * @param key
	 * @param setValue
	 * @return
	 */
	public static int setSetValue(String key, Set<String> setValue) {
		Jedis jedis = null;
		try {
			jedis = getResource();
			for (String str : setValue) {
				jedis.sadd(key, str);
			}
			return 0;
		} catch (Exception e) {
			pool.returnBrokenResource(jedis);
			e.printStackTrace();
			return -1;
		} finally {
			pool.returnResource(jedis);
		}
	}

	public static Set<String> getSetValue(String key) {
		Jedis jedis = null;
		try {
			jedis = getResource();
			return jedis.smembers(key);

		} catch (Exception e) {
			pool.returnBrokenResource(jedis);
			e.printStackTrace();
			return null;

		} finally {
			pool.returnResource(jedis);
		}
	}

	public static List<String> mgetStringValue(String[] keyList) {
		Jedis jedis = null;
		try {
			jedis = getResource();
			return jedis.mget(keyList);
		} catch (Exception e) {
			pool.returnBrokenResource(jedis);
			e.printStackTrace();
			return null;
		} finally {
			pool.returnResource(jedis);
		}

	}

	public static String getScriptLoadSha(String script) {
		Jedis jedis = null;
		try {
			jedis = getResource();
			return jedis.scriptLoad(script);
		} catch (Exception e) {
			pool.returnBrokenResource(jedis);
			e.printStackTrace();
			return null;
		} finally {
			pool.returnResource(jedis);
		}
	}

	public static long executeScript(String sha1, int keyCount, String... params) {
		Jedis jedis = null;
		try {
			jedis = getResource();
			return (long) jedis.evalsha(sha1, keyCount, params);
		} catch (Exception e) {
			pool.returnBrokenResource(jedis);
			e.printStackTrace();
			return -1;
		} finally {
			pool.returnResource(jedis);
		}
	}

	public static void init() {

	}
}
