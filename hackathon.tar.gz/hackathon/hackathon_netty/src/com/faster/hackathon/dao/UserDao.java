/**
 * hzr
 * Copyright (c) 2004-2015 All Rights Reserved.
 */
package com.faster.hackathon.dao;

import java.util.List;
import java.util.Map;

import com.faster.hackathon.entities.User;

public interface UserDao {

	public User getUserById(int userId);

	public User getUserByName(String name);

	public String getPassword(int userId);

	public List<User> getAllUsers();

	public Map<String, User> getUserMap();

	public void setUserMap(Map<String, User> map);
}
