/**
 * hzr
 * Copyright (c) 2004-2015 All Rights Reserved.
 */
package com.faster.hackathon.dao;

import java.util.List;

import com.faster.hackathon.entities.Food;

public interface FoodDao {

	public Food getFood(int foodId);

	public int getFoodStock(int foodId);

	public int getFoodPrice(int foodId);

	public List<Food> getAllFoods();

	public void updateFoodStock(int foodId);
}
