/**
 * hzr
 * Copyright (c) 2004-2015 All Rights Reserved.
 */
package com.faster.hackathon.dao.impl;

import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.List;
import java.util.Properties;

import com.faster.hackathon.dao.FoodDao;
import com.faster.hackathon.entities.Food;
import com.faster.hackathon.redis.JedisUtil;
import com.faster.hackathon.utils.ConstantsValue;
import com.faster.hackathon.utils.EnvDataUtil;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapClientBuilder;

public class FoodDaoImpl implements FoodDao {

	private static SqlMapClient sqlMapClient = null;
	public static List<Food> foodList = null;
	public static String foodListJson = null;

	static {
		try {
			// Reader reader = Resources
			// .getResourceAsReader("com/faster/hackathon/db/SqlMapconfig.xml");

			InputStream in = JedisUtil.class.getClassLoader()
					.getResourceAsStream("com/faster/hackathon/resource/SqlMapconfig.xml");
			Properties props = new Properties();
			props = new Properties();
			props.setProperty(ConstantsValue.URL,
					"jdbc:mysql://" + EnvDataUtil.DB_HOST + ":" + EnvDataUtil.DB_PORT + "/" + EnvDataUtil.DB_NAME);
			props.setProperty(ConstantsValue.USERNAME, EnvDataUtil.DB_USER);
			props.setProperty(ConstantsValue.PAWWSORD, EnvDataUtil.DB_PASS);
			sqlMapClient = SqlMapClientBuilder.buildSqlMapClient(in, props);
			in.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * @see com.faster.hackathon.dao.FoodDao#getFood(int)
	 */
	@Override
	public Food getFood(int foodId) {
		return null;
	}

	/**
	 * @see com.faster.hackathon.dao.FoodDao#getFoodStock(int)
	 */
	@Override
	public int getFoodStock(int foodId) {
		return 0;
	}

	/**
	 * @see com.faster.hackathon.dao.FoodDao#getFoodPrice(int)
	 */
	@Override
	public int getFoodPrice(int foodId) {
		return 0;
	}

	/**
	 * @throws SQLException
	 * @see com.faster.hackathon.dao.FoodDao#getAllFoods()
	 */
	@Override
	public List<Food> getAllFoods() {
		List<Food> foods = null;
		try {
			foods = (List<Food>) sqlMapClient.queryForList("selectAllFood");
		} catch (Exception e) {

		}
		return foods;
	}

	/**
	 * @see com.faster.hackathon.dao.FoodDao#updateFoodStock(int)
	 */
	@Override
	public void updateFoodStock(int foodId) {
	}

}
