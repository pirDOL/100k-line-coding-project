/**
 * hzr
 * Copyright (c) 2004-2015 All Rights Reserved.
 */
package com.faster.hackathon.dao;

public interface PurchaseDao {

	public void saveCart(String accessToken, String cartId);

	public boolean addFood(int foodId, int count, String accessToken, String cartId);

	public boolean purchaseOrder(String accessToken, String cartId);

}
