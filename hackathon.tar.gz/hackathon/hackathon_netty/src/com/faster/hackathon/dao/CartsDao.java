/**
 * hzr
 * Copyright (c) 2004-2015 All Rights Reserved.
 */
package com.faster.hackathon.dao;

public interface CartsDao {

	public void saveCartsId(String accessToken, String cardId);

	public void getCartsId(String accessToken);
}
