package com.faster.hackathon.server;

import java.net.URI;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;

import com.faster.hackathon.service.AddFoodHandler;
import com.faster.hackathon.service.CreateCartHandler;
import com.faster.hackathon.service.HttpRequestHandler;
import com.faster.hackathon.service.LoginHandler;
import com.faster.hackathon.service.OrderHandler;
import com.faster.hackathon.service.QueryFoodsHandler;
import com.faster.hackathon.service.QueryOrderHandler;
import com.faster.hackathon.service.ServiceEnum;

import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandler.Sharable;
import io.netty.channel.ChannelHandlerAdapter;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.http.DefaultFullHttpResponse;
import io.netty.handler.codec.http.FullHttpResponse;
import io.netty.handler.codec.http.HttpContent;
import io.netty.handler.codec.http.HttpMethod;
import io.netty.handler.codec.http.HttpRequest;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.netty.handler.codec.http.HttpVersion;

/**
 * Handler implementation for the echo server.
 */
@Sharable
public class NettyServerHandler extends ChannelHandlerAdapter {

	public Map<ServiceEnum, HttpRequestHandler> handlers = new EnumMap<ServiceEnum, HttpRequestHandler>(
			ServiceEnum.class);
	public Map<String, ServiceEnum> serviceMap = new HashMap<String, ServiceEnum>();

	public NettyServerHandler() {
		handlers.put(ServiceEnum.LOGIN, new LoginHandler());
		handlers.put(ServiceEnum.CREATE_CART, new CreateCartHandler());
		handlers.put(ServiceEnum.ADD_FOOD, new AddFoodHandler());
		handlers.put(ServiceEnum.QUERY_FOODS, new QueryFoodsHandler());
		handlers.put(ServiceEnum.ORDER, new OrderHandler());
		handlers.put(ServiceEnum.QUERY_ORDER, new QueryOrderHandler());

		serviceMap.put("/login", ServiceEnum.LOGIN);
		serviceMap.put("/carts", ServiceEnum.CREATE_CART);
		serviceMap.put("/carts/", ServiceEnum.ADD_FOOD);
		serviceMap.put("/foods", ServiceEnum.QUERY_FOODS);
		serviceMap.put("/orders", ServiceEnum.ORDER);
		serviceMap.put("/orders/", ServiceEnum.QUERY_ORDER);
		serviceMap.put("/admin/orders", ServiceEnum.ADMIN_ORDERS);
	}

	@Override
	public void channelRead(ChannelHandlerContext ctx, Object msg) {
		try {
			HttpRequest request = null;
			HttpRequestHandler handler = null;
			if (msg instanceof HttpRequest) {
				request = (HttpRequest) msg;
				URI uri = new URI(request.uri());
				String mapKey = null;
				if (request.method().compareTo(HttpMethod.POST) == 0) {
					mapKey = uri.getPath();
				} else if (request.method().compareTo(HttpMethod.PATCH) == 0) {
					mapKey = "/carts/";
				} else if (request.method().compareTo(HttpMethod.GET) == 0) {
					mapKey = uri.getPath();
					if (mapKey.equals("/orders")) {
						mapKey = mapKey + "/";
					}

				}

				handler = handlers.get(serviceMap.get(mapKey));

			}
			if (msg instanceof HttpContent) {
				// HttpContent content = (HttpContent) msg;
				// ByteBuf buf = content.content();
				// System.out.println(buf.toString(io.netty.util.CharsetUtil.UTF_8));
				// buf.release();
				FullHttpResponse response = new DefaultFullHttpResponse(HttpVersion.HTTP_1_1, HttpResponseStatus.OK);
				response.headers().set("CONTENT_TYPE", "application/json;charset=UTF-8");
				if (handler != null)
					handler.doAction(msg, response);

				response.headers().setInt("CONTENT_LENGTH", response.content().readableBytes());
				Channel channel = ctx.channel();
				ChannelFuture future = channel.write(response);
				future.addListener(ChannelFutureListener.CLOSE);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// ReferenceCountUtil.release(msg);
		}
	}

	@Override
	public void channelReadComplete(ChannelHandlerContext ctx) {
		ctx.flush();

	}

	@Override
	public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
		// Close the connection when an exception is raised.
		cause.printStackTrace();
		ctx.close();
	}
}
