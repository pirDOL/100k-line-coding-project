/**
 * hzr
 * Copyright (c) 2004-2015 All Rights Reserved.
 */
package com.faster.hackathon.entities;

public class Order {
	int userId;
	int foodId;
	int count;
	int totalPrice;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getFoodId() {
		return foodId;
	}

	public void setFoodId(int foodId) {
		this.foodId = foodId;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public int getPrice() {
		return totalPrice;
	}

	public void setPrice(int price) {
		this.totalPrice = price;
	}

	@Override
	public String toString() {
		return "Order [userId=" + userId + ", foodId=" + foodId + ", count=" + count + ", totalPrice=" + totalPrice
				+ "]";
	}

}
