/**
 * hzr
 * Copyright (c) 2004-2015 All Rights Reserved.
 */
package com.faster.hackathon.entities;

public class Food {
	int id;
	int stock;
	int price;

	public Food() {
		super();
	}

	public Food(int id, int stock, int price) {
		super();
		this.id = id;
		this.stock = stock;
		this.price = price;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Foods [id=" + id + ", stock=" + stock + ", price=" + price + "]";
	}

}
