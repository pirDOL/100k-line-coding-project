package com.faster.hackathon.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import com.faster.hackathon.redis.JedisUtil;

public class RedisTest {

	@Test
	public void testExisitKey() {
		System.out.println(JedisUtil.exisitKey("name"));
	}

	@Test
	public void testString() {
		JedisUtil.setStringValue("name", "eichy");
		System.out.println(JedisUtil.getStringValue("name1"));
	}

	@Test
	public void testMap() {
		Map<String, String> map = new HashMap<String, String>();
		map.put("a", "1");
		map.put("b", "2");
		map.put("c", "3");
		map.put("d", "4");
		map.put("e", "5");

		JedisUtil.setMapValue("map1", map);
		System.out.println(JedisUtil.getMapValue("map1"));
	}

	@Test
	public void testList() {
		List<String> list = new ArrayList<String>();

		list.add("a");
		list.add("ab");
		list.add("abc");
		list.add("abcd");
		list.add("abcde");

		JedisUtil.setListValue("list1", list);
		System.out.println(JedisUtil.getListValue("list1"));
	}

	@Test
	public void testSet() {
		HashSet<String> set = new HashSet<String>();
		set.add("a1");
		set.add("a2");
		set.add("a3");
		set.add("a4");

		JedisUtil.setSetValue("set1", set);
		System.out.println(JedisUtil.getSetValue("set1"));

	}

}
