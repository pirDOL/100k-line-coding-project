package com.faster.hackathon.test;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.junit.Test;

public class Log4JTest {
	private static Logger logger = Logger.getLogger(Test.class);

	@Test
	public void testLog4j() {
		PropertyConfigurator.configure(ClassLoader.getSystemResource("com/faster/hackathon/resource/log4j.properties"));
		logger.debug("This is debug message.");
		// ��¼info�������Ϣ
		logger.info("This is info message.");
		// ��¼error�������Ϣ
		logger.error("This is error message.");
	}
}
