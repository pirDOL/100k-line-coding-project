/**
 * hzr
 * Copyright (c) 2004-2015 All Rights Reserved.
 */
package com.faster.hackathon.test;

import java.util.Map;
import java.util.Set;

import org.junit.Test;

/**
 * 
 * @author  hzr
 * @version $Id: EnvTest.java, v 0.1 2015��11��9�� ����10:30:06 hzr  $
 */
public class EnvTest {

    @Test
    public void envTest() {
        Map<String, String> map = System.getenv();
        Set<Map.Entry<String, String>> entries = map.entrySet();
        for (Map.Entry<String, String> entry : entries) {
            System.out.println(entry.getKey() + ":" + entry.getValue());
        }
    }
}
