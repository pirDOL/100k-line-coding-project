/**
 * hzr
 * Copyright (c) 2004-2015 All Rights Reserved.
 */
package com.faster.hackathon.test;

import java.util.concurrent.CountDownLatch;

import org.junit.Test;

import com.faster.hackathon.app.Startup;
import com.faster.hackathon.redis.JedisUtil;

/**
 * 
 * @author  hzr
 * @version $Id: BootTest.java, v 0.1 2015��11��8�� ����12:58:33 hzr  $
 */
public class BootTest {

    private int            threadSize     = 10;
    private CountDownLatch countDownLatch = new CountDownLatch(threadSize);

    @Test
    public void bootTest() {

        for (int i = 0; i < threadSize; i++) {
            new Thread(new StartupThread(countDownLatch)).start();
        }

        try {
            countDownLatch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println(JedisUtil.getResource().get("BOOTKEY") + ",ttl:"
                           + JedisUtil.getResource().ttl("BOOTKEY"));

    }

}

class StartupThread implements Runnable {

    private CountDownLatch countDownLatch;

    public StartupThread(CountDownLatch countDownLatch) {
        super();
        this.countDownLatch = countDownLatch;
    }

    /** 
     * @see java.lang.Runnable#run()
     */
    @Override
    public void run() {
        Startup startUp = new Startup();
        try {
            startUp.init();
        } catch (Exception e) {
            e.printStackTrace();
        }
        countDownLatch.countDown();

    }

}