/**
 * hzr
 * Copyright (c) 2004-2015 All Rights Reserved.
 */
package com.faster.hackathon.test;

import java.util.List;

import org.junit.Test;

import com.faster.hackathon.dao.FoodDao;
import com.faster.hackathon.dao.UserDao;
import com.faster.hackathon.dao.impl.FoodDaoImpl;
import com.faster.hackathon.dao.impl.UserDaoImpl;
import com.faster.hackathon.entities.Food;

/**
 * 
 * @author  hzr
 * @version $Id: DBtest.java, v 0.1 2015��11��9�� ����2:50:07 hzr  $
 */
public class DBtest {

    @Test
    public void testUser() {
        UserDao userDao = new UserDaoImpl();
        System.out.println(userDao.getUserById(31));
    }

    @Test
    public void testFood() {
        FoodDao foodDao = new FoodDaoImpl();
        List<Food> foodList = foodDao.getAllFoods();

        System.out.println(foodDao.getAllFoods());
    }

}
