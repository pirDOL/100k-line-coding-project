/**
 * hzr
 * Copyright (c) 2004-2015 All Rights Reserved.
 */
package com.faster.hackathon.test;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.faster.hackathon.utils.JsonUtil;

/**
 * 
 * @author hzr
 * @version $Id: JsonTest.java, v 0.1 2015��11��9�� ����9:15:38 hzr $
 */
public class JsonTest {

	@Test
	public void testGetJSONArray() {
		System.out.println(JsonUtil.getItemJsonArray("1 1 2 2 3 0 ").toString());
	}

	@Test
	public void testJsonUtil() {
		long startTime = System.currentTimeMillis(); // ��ȡ��ʼʱ��
		Map<String, String> map = new HashMap<String, String>();
		map.put("userId", "1");
		map.put("password", "22");
		for (int i = 0; i < 1000000; i++) {
			map.put("userId", String.valueOf(i));
			String str = JSON.toJSONString(map);
		}

		long endTime = System.currentTimeMillis(); // ��ȡ����ʱ��

		System.out.println(endTime - startTime);
	}

	@Test
	public void testJsonString() {
		long startTime = System.currentTimeMillis(); // ��ȡ��ʼʱ��
		Map<String, String> map = new HashMap<String, String>();
		map.put("userId", "1");
		map.put("password", "22");
		for (int i = 0; i < 1000000; i++) {
			map.put("userId", String.valueOf(i));
			String str = "{" + "userId:" + i + "\n" + "passowrd:" + "22}";
		}

		long endTime = System.currentTimeMillis(); // ��ȡ����ʱ��

		System.out.println(endTime - startTime);
	}
}
