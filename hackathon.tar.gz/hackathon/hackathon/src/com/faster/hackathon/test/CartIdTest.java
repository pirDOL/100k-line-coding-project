package com.faster.hackathon.test;

import org.junit.Test;

import com.faster.hackathon.utils.CartIdUtil;

public class CartIdTest {
	@Test
	public void testCartId() {
		System.out.println(CartIdUtil.isValidCartId("AA0EBB00E29B33D4A716446655B00001"));
	}
}
