package com.faster.hackathon.test;

import org.junit.Test;

import com.faster.hackathon.utils.EnvDataUtil;

public class EnvDataTest {

	@Test
	public void testEven() {
		System.out.println(EnvDataUtil.APP_HOST);
		System.out.println(EnvDataUtil.APP_PORT);
		System.out.println(EnvDataUtil.DB_HOST);
		System.out.println(EnvDataUtil.DB_PORT);
		System.out.println(EnvDataUtil.DB_NAME);
		System.out.println(EnvDataUtil.DB_USER);
		System.out.println(EnvDataUtil.DB_PASS);
		System.out.println(EnvDataUtil.REDIS_HOST);
		System.out.println(EnvDataUtil.REDIS_PORT);

	}

}
