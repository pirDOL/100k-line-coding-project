/**
 * hzr
 * Copyright (c) 2004-2015 All Rights Reserved.
 */
package com.faster.hackathon.redis;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import com.faster.hackathon.dao.FoodDao;
import com.faster.hackathon.dao.UserDao;
import com.faster.hackathon.dao.impl.FoodDaoImpl;
import com.faster.hackathon.dao.impl.UserDaoImpl;
import com.faster.hackathon.entities.Food;
import com.faster.hackathon.entities.User;
import com.faster.hackathon.utils.EnvDataUtil;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

/**
 * @author hfy
 *
 */
public class JedisUtil {
    private static JedisPool pool;

    public static JedisPool getPool() {
        return pool;
    }

    private static final String BOOT_KEY     = "BOOTKEY";

    private static final String START_OVER   = "START_OVER";

    private final static String BOOT_UUID    = java.util.UUID.randomUUID().toString().replace("-",
        "");

    private static final int    EXPIRED_TIME = 60 * 5;
    private static final long   TOKEN_OWNER  = 1;

    static {
        InputStream is = JedisUtil.class.getClassLoader()
            .getResourceAsStream("com/faster/hackathon/resource/jedis.properties");
        Properties props = new Properties();

        props = new Properties();

        if (is == null) {
            System.out.println("is is null");

        }

        try {
            props.load(is);
            JedisPoolConfig config = new JedisPoolConfig();
            config.setMaxActive(Integer.valueOf(props.getProperty("redis.pool.maxActive").trim()));
            config.setMaxIdle(Integer.valueOf(props.getProperty("redis.pool.maxIdle").trim()));
            config.setMaxWait(Long.valueOf(props.getProperty("redis.pool.maxWait").trim()));
            config.setTestOnBorrow(
                Boolean.valueOf(props.getProperty("redis.pool.testOnBorrow").trim()));
            config.setTestOnReturn(
                Boolean.valueOf(props.getProperty("redis.pool.testOnReturn").trim()));
            pool = new JedisPool(config, EnvDataUtil.REDIS_HOST.trim(), EnvDataUtil.REDIS_PORT);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * ��ʼ��redis����mysql���ݸ��Ƶ�redis
     */
    static {

        System.out.println("init redis data");
        Jedis jedis = null;
        try {
            jedis = getResource();
            UserDao userDao = new UserDaoImpl();
            List<User> userList = userDao.getAllUsers();
            System.out.println("get userList");
            Map<String, User> mapUser = new HashMap<String, User>(180);
            Map<String, String> mapUserToken = null;

            FoodDao foodDao = new FoodDaoImpl();
            List<Food> foodList = foodDao.getAllFoods();
            System.out.println("get foodList");
            List<String> stockkeysList = new ArrayList<String>(foodList.size());
            //mapUserToken = new HashMap<String, String>(12500);

            for (User user : userList) {
                mapUser.put(user.getName(), user);
            }
            userDao.setUserMap(mapUser);
            long response = jedis.setnx(BOOT_KEY, BOOT_UUID);
            if (response == 1) {
                System.out.println("set data to redis");

                jedis.expire(BOOT_KEY, EXPIRED_TIME);
                // TODO: init jedis data
                long startTime = System.currentTimeMillis();
                for (Food food : foodList) {
                    jedis.set("price:" + food.getId(), String.valueOf(food.getPrice()));
                    jedis.set("stock:" + food.getId(), String.valueOf(food.getStock()));
                    FoodDaoImpl.foodMap.put(String.valueOf(food.getId()), food);
                    stockkeysList.add("stock:" + food.getId());
                }

                System.out.println("set food finish");

                FoodDaoImpl.stockKeys = new String[stockkeysList.size()];
                stockkeysList.toArray(FoodDaoImpl.stockKeys);

                //                Pipeline p = jedis.pipelined();
                //
                //                for (User user : userList) {
                //                    String token = UUID.randomUUID().toString().replace("-", "");
                //                    mapUserToken.put(String.valueOf(user.getId()).trim(), token);
                //                    p.set(ConstantsValue.USER + ConstantsValue.KEY_SPILITTER + user.getId(), token);
                //                }
                //                p.sync();

                System.out.println("set token finish");
                //jedis.hmset(ConstantsValue.ACCESS_TOKEN_KEYS, mapUserToken);

                long endTime = System.currentTimeMillis();
                System.out.println("init redis time:" + (endTime - startTime));
                jedis.set(START_OVER, "TRUE");
                System.out.println("set start over:" + System.currentTimeMillis());
            } else {

                for (Food food : foodList) {
                    FoodDaoImpl.foodMap.put(String.valueOf(food.getId()), food);
                    stockkeysList.add("stock:" + food.getId());
                }
                FoodDaoImpl.stockKeys = new String[stockkeysList.size()];
                stockkeysList.toArray(FoodDaoImpl.stockKeys);

                // get the token from redis
                //                System.out.println("get data from redis");
                //                String value = jedis.get(START_OVER);
                //                while (value == null || value.isEmpty()) {
                //                    Thread.sleep(3000);
                //                    value = jedis.get(START_OVER);
                //                    System.out.println("wait for read from jedis data");
                //                }
                //mapUserToken = jedis.hgetAll(ConstantsValue.ACCESS_TOKEN_KEYS);
                System.out.println("get START_OVER data end");

                //                for (User user : userList) {
                //                    String token = jedis
                //                        .get(ConstantsValue.USER + ConstantsValue.KEY_SPILITTER + user.getId());
                //                    mapUserToken.put(String.valueOf(user.getId()), token);
                //                }
                System.out.println("get token data end");
                //                if (mapUserToken == null || mapUserToken.isEmpty()) {
                //                    System.out.println("mapUserToken is null");
                //                }
            }
            //AccessTokenUtil.setMapUserToken(mapUserToken);
            System.out.println("init redis data end");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pool.returnResource(jedis);
        }
    }

    public static Jedis getResource() {
        return pool.getResource();
    }

    /**
     * HFY::�ж�key�Ƿ���ڣ����ڷ���true�������ڷ���false
     * 
     * @param key
     * @return
     */
    public static boolean exisitKey(String key) {
        Jedis jedis = null;
        // HFY::�쳣����
        try {
            jedis = getResource();
            return jedis.exists(key);
        } catch (Exception e) {
            pool.returnBrokenResource(jedis);
            e.printStackTrace();
            return false;
        } finally {
            // HFY::��jedis��Դ���ص����ӳ�
            pool.returnResource(jedis);
        }
    }

    /**
     * HFY::����ֵ0��ʾset�ɹ�������-1��ʾsetʧ��
     * 
     * @param key
     * @param stringValue
     */
    public static int setStringValue(String key, String stringValue) {
        Jedis jedis = null;
        // HFY::�쳣����
        try {
            jedis = getResource();
            jedis.set(key, stringValue);
            return 0;
        } catch (Exception e) {
            pool.returnBrokenResource(jedis);
            e.printStackTrace();
            return -1;
        } finally {
            // HFY::��jedis��Դ���ص����ӳ�
            pool.returnResource(jedis);
        }
    }

    public static String getStringValue(String key) {
        Jedis jedis = null;
        try {
            jedis = getResource();
            return jedis.get(key);
        } catch (Exception e) {
            pool.returnBrokenResource(jedis);
            e.printStackTrace();
            return null;
        } finally {
            pool.returnResource(jedis);
        }

    }

    public static int setMapValue(String key, Map<String, String> mapValue) {
        Jedis jedis = null;
        try {
            jedis = getResource();
            jedis.hmset(key, mapValue);
            return 0;
        } catch (Exception e) {
            pool.returnBrokenResource(jedis);
            e.printStackTrace();
            return -1;
        } finally {
            pool.returnResource(jedis);
        }

    }

    public static Map<String, String> getMapValue(String key) {
        Jedis jedis = null;
        try {
            jedis = getResource();
            return jedis.hgetAll(key);

        } catch (Exception e) {
            pool.returnBrokenResource(jedis);
            e.printStackTrace();
            return null;

        } finally {
            pool.returnResource(jedis);
        }
    }

    /**
     * HFY::Redisû���ṩ��list����Ĵ洢�ӿڣ�ֻ�ṩ����listԪ�صĴ洢�ӿ� HFY::��ѭ���Ե���Ԫ�ش洢��redis��
     * HFY::���߲��ղ��ʹ洢List���󣿣�������������������
     * http://blog.csdn.net/gstormspire/article/details/7653095
     * 
     * @param key
     * @param listValue
     * @return
     */
    public static int setListValue(String key, List<String> listValue) {
        Jedis jedis = null;
        try {
            jedis = getResource();

            for (String str : listValue) {
                jedis.lpush(key, str);
            }
            return 0;
        } catch (Exception e) {
            pool.returnBrokenResource(jedis);
            e.printStackTrace();
            return -1;
        } finally {
            pool.returnResource(jedis);
        }
    }

    public static List<String> getListValue(String key) {
        Jedis jedis = null;
        try {
            jedis = getResource();
            return jedis.lrange(key, 0, -1);

        } catch (Exception e) {
            pool.returnBrokenResource(jedis);
            e.printStackTrace();
            return null;

        } finally {
            pool.returnResource(jedis);
        }
    }

    /**
     * HFY::Ҳ���������setԪ��,�鿴һ����û���������õķ�ʽ����������������
     * 
     * @param key
     * @param setValue
     * @return
     */
    public static int setSetValue(String key, Set<String> setValue) {
        Jedis jedis = null;
        try {
            jedis = getResource();
            for (String str : setValue) {
                jedis.sadd(key, str);
            }
            return 0;
        } catch (Exception e) {
            pool.returnBrokenResource(jedis);
            e.printStackTrace();
            return -1;
        } finally {
            pool.returnResource(jedis);
        }
    }

    public static Set<String> getSetValue(String key) {
        Jedis jedis = null;
        try {
            jedis = getResource();
            return jedis.smembers(key);

        } catch (Exception e) {
            pool.returnBrokenResource(jedis);
            e.printStackTrace();
            return null;

        } finally {
            pool.returnResource(jedis);
        }
    }

    public static List<String> mgetStringValue(String[] keyList) {
        Jedis jedis = null;
        try {
            jedis = getResource();
            return jedis.mget(keyList);
        } catch (Exception e) {
            pool.returnBrokenResource(jedis);
            e.printStackTrace();
            return null;
        } finally {
            pool.returnResource(jedis);
        }

    }

    public static String getScriptLoadSha(String script) {
        Jedis jedis = null;
        try {
            jedis = getResource();
            return jedis.scriptLoad(script);
        } catch (Exception e) {
            pool.returnBrokenResource(jedis);
            e.printStackTrace();
            return null;
        } finally {
            pool.returnResource(jedis);
        }
    }

    public static long executeScript(String sha1, int keyCount, String... params) {
        Jedis jedis = null;
        try {
            jedis = getResource();
            return (long) jedis.evalsha(sha1, keyCount, params);
        } catch (Exception e) {
            pool.returnBrokenResource(jedis);
            e.printStackTrace();
            return -1;
        } finally {
            pool.returnResource(jedis);
        }
    }

    public static void init() {

    }
}
