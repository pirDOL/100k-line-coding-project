package com.faster.hackathon.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Scanner;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.faster.hackathon.redis.JedisUtil;
import com.faster.hackathon.utils.ConstantsValue;
import com.faster.hackathon.utils.JsonUtil;

/**
 * Servlet implementation class Order
 */
// @WebServlet("/orders")
public class Order extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private static String     SHA_ORDER        = "";

    private static Logger     logger           = Logger.getLogger(Order.class);

    public static void initClass() {
        InputStream in = Carts.class.getClassLoader()
            .getResourceAsStream("com/faster/hackathon/resource/order.lua");
        try {
            Scanner scanner = new Scanner(in);
            String script = "";
            while (scanner.hasNext()) {
                script += scanner.nextLine() + " ";
            }
            in.close();
            SHA_ORDER = JedisUtil.getScriptLoadSha(script);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * @see HttpServlet#HttpServlet()
     */
    public Order() {
        super();
        // TODO Auto-generated constructor stub
    }

    @Override
    public void init() throws ServletException {
        // TODO Auto-generated method stub
        super.init();
        JSONObject jso1 = JSONObject.parseObject(ConstantsValue.JSON_ONE_PARAM);

    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        try {
            logger.error("Order.doPost start");
            response.setCharacterEncoding(ConstantsValue.ENCODINGTYPE);

            String cartId = "";
            String accessToken = request.getParameter(ConstantsValue.ACCESS_TOKEN);
            if (accessToken == null || accessToken.isEmpty()) {
                accessToken = request.getHeader(ConstantsValue.ACCESS_TOKEN_HEADER);
            }

            if (accessToken == null || accessToken.isEmpty()) {
                processResponse(response, 401, ConstantsValue.CODE,
                    ConstantsValue.INVALID_ACCESS_TOKEN, ConstantsValue.MESSAGE,
                    ConstantsValue.MESSAGE_INVALID_TOKEN);
            } else {
                try {
                    String acceptjson = JsonUtil.getJsonString(request);
                    if (!acceptjson.isEmpty()) {
                        JSONObject jb = JSONObject.parseObject(acceptjson);
                        cartId = jb.getString(ConstantsValue.CART_ID);

                        //��ȡ����ACCESS_TOKEN��������Ȩ�޷���ָ�������ӡ�
                        //                        if (!AccessTokenUtil.isValidToken(accessToken)) {
                        //                            processResponse(response, 401, ConstantsValue.CODE,
                        //                                ConstantsValue.NOT_AUTHORIZED_TO_ACCESS_CART,
                        //                                ConstantsValue.MESSAGE,
                        //                                ConstantsValue.MESSAGE_NOT_AUTHORIZED_TO_ACCESS_CART);
                        //                            return;
                        //                        }

                        // realCartIdΪ�գ��������Ӳ����ڡ�
                        // if (!CartIdUtil.isValidCartId(cartId)) {
                        // processResponse(response, 404, ConstantsValue.CODE,
                        // ConstantsValue.CART_NOT_FOUND,
                        // ConstantsValue.MESSAGE,
                        // ConstantsValue.MESSAGE_CART_NOT_FOUND);
                        // return;
                        // }

                        String orderKey = ConstantsValue.CART + ConstantsValue.KEY_SPILITTER
                                          + accessToken + ConstantsValue.KEY_SPILITTER + cartId;

                        // �µ�
                        long dataResult = JedisUtil.executeScript(SHA_ORDER, 1, orderKey,
                            accessToken);

                        if (dataResult > 0) {
                            response.setStatus(200);
                            String jsonStr = "{\"" + ConstantsValue.ID + "\":\"" + dataResult
                                             + "\"}";
                            response.getWriter().write(jsonStr);
                            return;
                        } else if (dataResult == -1) {
                            processResponse(response, 401, ConstantsValue.CODE,
                                ConstantsValue.NOT_AUTHORIZED_TO_ACCESS_CART,
                                ConstantsValue.MESSAGE,
                                ConstantsValue.MESSAGE_NOT_AUTHORIZED_TO_ACCESS_CART);
                            return;
                        } else if (dataResult == -2) {
                            // ÿ���û�ֻ����һ��
                            processResponse(response, 403, ConstantsValue.CODE,
                                ConstantsValue.ORDER_OUT_OF_LIMIT, ConstantsValue.MESSAGE,
                                ConstantsValue.MESSAGE_ORDER_OUT_OF_LIMIT);
                            return;
                        } else if (dataResult == -3) {
                            // ʳ���治��
                            processResponse(response, 403, ConstantsValue.CODE,
                                ConstantsValue.FOOD_OUT_OF_STOCK, ConstantsValue.MESSAGE,
                                ConstantsValue.MESSAGE_FOOD_OUT_OF_STOCK);
                            return;
                        }

                    } else {
                        response.setStatus(204);
                        response.getWriter().flush();
                        //response.getWriter().close();

                    }
                } catch (Exception e) {

                }
            }
        } finally {
            logger.error("Order.doPost finish");
        }
    }

    /**
     * ��ѯ����
     * 
     * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest,
     *      javax.servlet.http.HttpServletResponse)
     */
    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response) throws ServletException, IOException {
        response.setCharacterEncoding(ConstantsValue.ENCODINGTYPE);
        String accessToken = request.getParameter(ConstantsValue.ACCESS_TOKEN);
        if (accessToken == null || accessToken.isEmpty()) {
            accessToken = request.getHeader(ConstantsValue.ACCESS_TOKEN_HEADER);
        }

        if (accessToken == null || accessToken.isEmpty()) {
            processResponse(response, 401, ConstantsValue.CODE, ConstantsValue.INVALID_ACCESS_TOKEN,
                ConstantsValue.MESSAGE, ConstantsValue.MESSAGE_INVALID_TOKEN);
        } else {

            String orderKey = ConstantsValue.ORDER + ":" + accessToken;
            Map<String, String> orderMapValue = JedisUtil.getMapValue(orderKey);

            // order:<access_token>�����ڣ�getMapValue���ز���null������orderMapValueΪ��
            if (orderMapValue == null || orderMapValue.isEmpty()) {
                // JSONArray jsa = new JSONArray();
                response.getWriter().write("[]");
                return;
            }

            String orderId = orderMapValue.get(ConstantsValue.ORDER_ID);
            String items = orderMapValue.get(ConstantsValue.ITEMS);
            String total = orderMapValue.get(ConstantsValue.TOTAL);

            JSONObject jso = new JSONObject();
            jso.put(ConstantsValue.ORDER_ID, orderId);
            jso.put(ConstantsValue.ITEMS, JsonUtil.getItemJsonArray(items));
            jso.put(ConstantsValue.TOTAL, Integer.valueOf(total));

            JSONArray jsa = new JSONArray();
            jsa.add(jso);
            response.getWriter().write(jsa.toString());
            response.getWriter().flush();
            //response.getWriter().close();

        }
    }

    private void processResponse(HttpServletResponse response, int responseCode, String msgName1,
                                 String msgContent1, String msgName2,
                                 String msgContent2) throws IOException {
        response.setStatus(responseCode);

        JSONObject jso = new JSONObject();
        jso.put(msgName1, msgContent1);
        jso.put(msgName2, msgContent2);

        response.getWriter().write(jso.toString());
    }

}
