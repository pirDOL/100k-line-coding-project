package com.faster.hackathon.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSONObject;
import com.faster.hackathon.redis.JedisUtil;
import com.faster.hackathon.utils.CartIdUtil;
import com.faster.hackathon.utils.ConstantsValue;
import com.faster.hackathon.utils.JsonUtil;
import com.faster.hackathon.utils.UUIDFactory;

/**
 * Servlet implementation class Carts
 */
// @WebServlet("/carts/*")
public class Carts extends HttpServlet {
    private static final long          serialVersionUID = 1L;
    private static String              SHA_PATCH        = "";

    private static Logger              logger           = Logger.getLogger(Carts.class);
    private static Map<String, String> initMapFoodCount = new HashMap<String, String>();

    public static void initClass() {
        InputStream in = Carts.class.getClassLoader()
            .getResourceAsStream("com/faster/hackathon/resource/patch.lua");
        try {
            Scanner scanner = new Scanner(in);
            String script = "";
            while (scanner.hasNext()) {
                script += scanner.nextLine() + " ";
            }
            in.close();
            SHA_PATCH = JedisUtil.getScriptLoadSha(script);
        } catch (IOException e) {
            e.printStackTrace();
        }

        initMapFoodCount.put("-1", "-1");
    }

    /**
     * @see HttpServlet#HttpServlet()
     */
    public Carts() {
        super();
        // TODO Auto-generated constructor stub
    }

    @Override
    public void init() throws ServletException {
        // TODO Auto-generated method stub
        super.init();
        JSONObject jso1 = JSONObject.parseObject(ConstantsValue.JSON_ONE_PARAM);
        JSONObject jso2 = JSONObject.parseObject(ConstantsValue.JSON_TWO_PARAMS);
    }

    @Override
    protected void service(HttpServletRequest request,
                           HttpServletResponse response) throws ServletException, IOException {
        if (request.getMethod().equals("PATCH")) {
            doPatch(request, response);
        } else {
            super.service(request, response);
        }
    }

    /**
     * ��ʳ����뵽���ﳵ
     * 
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void doPatch(HttpServletRequest request,
                           HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        try {
            logger.error("Carts.doPatch start");
            response.setCharacterEncoding(ConstantsValue.ENCODINGTYPE);

            String cartId = request.getPathInfo();
            cartId = cartId.substring(1, cartId.length());

            String accessToken = request.getParameter(ConstantsValue.ACCESS_TOKEN);
            if (accessToken == null || accessToken.isEmpty()) {
                accessToken = request.getHeader(ConstantsValue.ACCESS_TOKEN_HEADER);
            }

            if (accessToken == null || accessToken.isEmpty()) {
                processResponse(response, 401, ConstantsValue.CODE,
                    ConstantsValue.INVALID_ACCESS_TOKEN, ConstantsValue.MESSAGE,
                    ConstantsValue.MESSAGE_INVALID_TOKEN);
            } else {
                try {
                    String acceptjson = JsonUtil.getJsonString(request);
                    if (!acceptjson.isEmpty()) {
                        JSONObject jb = JSONObject.parseObject(acceptjson);
                        // int[] jsonArr = JsonUtil.parsePatchFood(acceptjson);
                        int foodId = jb.getIntValue(ConstantsValue.FOOD_ID);
                        // int foodId = jsonArr[0];
                        // jsonArr[1]);
                        if (foodId < 0) {
                            processResponse(response, 404, ConstantsValue.CODE,
                                ConstantsValue.FOOD_NOT_FOUND, ConstantsValue.MESSAGE,
                                ConstantsValue.MESSAGE_FOOD_NOT_FOUND);
                            return;
                        }

                        int count = jb.getIntValue(ConstantsValue.COUNT);
                        // int count = jsonArr[1];

                        // ��cartId���󣬱������Ӳ����ڡ�
                        if (!CartIdUtil.isValidCartId(cartId)) {
                            processResponse(response, 404, ConstantsValue.CODE,
                                ConstantsValue.CART_NOT_FOUND, ConstantsValue.MESSAGE,
                                ConstantsValue.MESSAGE_CART_NOT_FOUND);
                            return;
                        }

                        // ����ʳ��
                        long dataResult = JedisUtil.executeScript(SHA_PATCH,
                            1, ConstantsValue.CART + ConstantsValue.KEY_SPILITTER + accessToken
                               + ConstantsValue.KEY_SPILITTER + cartId,
                            String.valueOf(foodId), String.valueOf(count), cartId);

                        if (dataResult == 0) {
                            response.setStatus(204);
                            return;
                        } else if (dataResult == 1) {
                            processResponse(response, 403, ConstantsValue.CODE,
                                ConstantsValue.FOOD_OUT_OF_LIMIT, ConstantsValue.MESSAGE,
                                ConstantsValue.MESSAGE_FOOD_OUT_OF_LIMIT);
                            return;
                        } else if (dataResult == 2) {
                            // ����Ȩ�޷���ָ�������ӡ�
                            processResponse(response, 401, ConstantsValue.CODE,
                                ConstantsValue.NOT_AUTHORIZED_TO_ACCESS_CART,
                                ConstantsValue.MESSAGE,
                                ConstantsValue.MESSAGE_NOT_AUTHORIZED_TO_ACCESS_CART);
                            return;
                        }

                    } else {
                        response.setStatus(204);
                    }
                } catch (Exception e) {

                }
            }
        } finally {
            logger.error("Carts.doPatch finish");
        }

    }

    /**
     * �������ﳵ
     * 
     * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest,
     *      javax.servlet.http.HttpServletResponse)
     */
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        try {
            logger.error("Carts.doPost start");
            response.setCharacterEncoding(ConstantsValue.ENCODINGTYPE);
            String accessToken = request.getParameter(ConstantsValue.ACCESS_TOKEN);
            if (accessToken == null || accessToken.isEmpty()) {
                accessToken = request.getHeader(ConstantsValue.ACCESS_TOKEN_HEADER);
            }

            if (accessToken == null || accessToken.isEmpty()) {
                processResponse(response, 401, ConstantsValue.CODE,
                    ConstantsValue.INVALID_ACCESS_TOKEN, ConstantsValue.MESSAGE,
                    ConstantsValue.MESSAGE_INVALID_TOKEN);
            } else {
                String cartId = UUIDFactory.getCartId();

                String key = ConstantsValue.CART + ConstantsValue.KEY_SPILITTER + accessToken
                             + ConstantsValue.KEY_SPILITTER + cartId;
                JedisUtil.setMapValue(key, initMapFoodCount);

                String jsonStr = "{\"" + ConstantsValue.CART_ID + "\":\"" + cartId + "\"}";
                response.getWriter().write(jsonStr);
                response.getWriter().flush();
                //response.getWriter().close();

            }
        } finally {
            logger.error("Carts.doPost finish");
        }
    }

    private void processResponse(HttpServletResponse response, int responseCode, String msgName1,
                                 String msgContent1, String msgName2,
                                 String msgContent2) throws IOException {
        response.setStatus(responseCode);

        JSONObject jso = new JSONObject();
        jso.put(msgName1, msgContent1);
        jso.put(msgName2, msgContent2);

        response.getWriter().write(jso.toString());
        jso = null;
    }

}
