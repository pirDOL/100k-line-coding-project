package com.faster.hackathon.service;

import java.io.IOException;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.faster.hackathon.redis.JedisUtil;
import com.faster.hackathon.utils.AccessTokenUtil;
import com.faster.hackathon.utils.ConstantsValue;
import com.faster.hackathon.utils.JsonUtil;

public class AdminOrders extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        response.setCharacterEncoding(ConstantsValue.ENCODINGTYPE);
        String accessToken = request.getParameter(ConstantsValue.ACCESS_TOKEN);
        if (accessToken == null || accessToken.isEmpty()) {
            accessToken = request.getHeader(ConstantsValue.ACCESS_TOKEN_HEADER);
        }

        if (accessToken == null || accessToken.isEmpty()) {
            processResponse(response, 401, ConstantsValue.CODE, ConstantsValue.INVALID_ACCESS_TOKEN,
                ConstantsValue.MESSAGE, ConstantsValue.MESSAGE_INVALID_TOKEN);
        } else {
            String ordersKey = ConstantsValue.ORDERS;
            Set<String> ordersSet = JedisUtil.getSetValue(ordersKey);

            // order:<access_token>�����ڣ�getMapValue���ز���null������orderMapValueΪ��
            if (ordersSet == null || ordersSet.isEmpty()) {
                // JSONArray jsa = new JSONArray();
                response.getWriter().write("[]");
                return;
            }
            JSONArray jsonArray = new JSONArray();
            for (String token : ordersSet) {
                String orderKey = ConstantsValue.ORDER + ":" + token;
                Map<String, String> orderMapValue = JedisUtil.getMapValue(orderKey);
                String orderId = orderMapValue.get(ConstantsValue.ORDER_ID);
                String items = orderMapValue.get(ConstantsValue.ITEMS);
                String total = orderMapValue.get(ConstantsValue.TOTAL);

                JSONObject jso = new JSONObject();
                jso.put(ConstantsValue.ORDER_ID, orderId);
                jso.put(ConstantsValue.ITEMS, JsonUtil.getItemJsonArray(items));
                jso.put(ConstantsValue.TOTAL, Integer.valueOf(total));
                jso.put(ConstantsValue.USER_ID, Integer.valueOf(AccessTokenUtil.getUserId(token)));
                jsonArray.add(jso);
            }

            response.getWriter().write(jsonArray.toString());
            response.getWriter().flush();
            //response.getWriter().close();

        }

    }

    private void processResponse(HttpServletResponse response, int responseCode, String msgName1,
                                 String msgContent1, String msgName2,
                                 String msgContent2) throws IOException {
        response.setStatus(responseCode);

        JSONObject jso = new JSONObject();
        jso.put(msgName1, msgContent1);
        jso.put(msgName2, msgContent2);

        response.getWriter().write(jso.toString());
    }
}
