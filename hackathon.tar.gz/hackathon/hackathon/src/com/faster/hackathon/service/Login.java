package com.faster.hackathon.service;

import java.io.IOException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSONObject;
import com.faster.hackathon.dao.impl.UserDaoImpl;
import com.faster.hackathon.entities.User;
import com.faster.hackathon.redis.JedisUtil;
import com.faster.hackathon.utils.AccessTokenUtil;
import com.faster.hackathon.utils.ConstantsValue;
import com.faster.hackathon.utils.JsonUtil;
import com.faster.hackathon.utils.UUIDFactory;

/**
 * ��¼
 * 
 * @author hzr
 * @version $Id: Login.java, v 0.1 2015��11��5�� ����8:59:14 hzr $
 */
// @WebServlet("/login")
public class Login extends HttpServlet {
    private static final long serialVersionUID          = 1L;

    private static String     USER_AUTH_FAIL_STRING     = "{\"code\": \"USER_AUTH_FAIL\",\"message\": \"�û������������\"}";
    private static String     EMPTY_REQUEST_JSON_STRING = "{\"code\": \"EMPTY_REQUEST\",\"message\": \"������Ϊ��\"}";
    private static String     MALFORMED_JSON_STRING     = "{\"code\": \"MALFORMED_JSON\",\"message\": \"��ʽ����\"}";

    private static Logger     logger                    = Logger.getLogger(Login.class);

    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub

    }

    @Override
    public void init() throws ServletException {
        // TODO Auto-generated method stub
        super.init();
        System.out.println("Login servlet init");
        JSONObject jso = JSONObject.parseObject(ConstantsValue.JSON_TWO_PARAMS);
    }

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        logger.error("Login.doPost start");
        try {
            response.setCharacterEncoding("UTF-8");
            String acceptjson = JsonUtil.getJsonString(request);
            if (!acceptjson.isEmpty()) {
                JSONObject jb = JSONObject.parseObject(acceptjson);

                String username = jb.get("username").toString();
                String password = jb.getString("password").toString();
                // String[] jsonArr = JsonUtil.parseLogin(acceptjson);
                // String username = jsonArr[0];
                // String password = jsonArr[1];

                String realPassord = null;
                String accessToken = null;
                int userId = 0;
                String key = "user:" + username + ":" + password;

                String queryPassword = null;

                // �ȴӱ��ػ����в�ѯuser
                User user = UserDaoImpl.userMap.get(username);

                // ������ػ����в�����
                if (user == null) {
                    // �ٴ�redis�в�ѯ
                    Map<String, String> cachedUser = JedisUtil.getMapValue(key);
                    if (cachedUser != null && !cachedUser.isEmpty()) {
                        queryPassword = password;
                        userId = Integer.valueOf(cachedUser.get(ConstantsValue.USER_ID));
                    }

                } else {
                    queryPassword = user.getPassword();
                    userId = user.getId();
                }

                if (queryPassword == null || !queryPassword.equals(password)) {
                    response.setStatus(403);
                    response.getWriter().write(USER_AUTH_FAIL_STRING);
                    return;
                }

                user = null;

                //accessToken = AccessTokenUtil.getAccessToken(userId);
                accessToken = UUIDFactory.getToken();
                AccessTokenUtil.saveAccessToken(userId, accessToken);

                // ��¼�ɹ�
                // {
                // "user_id": 1,
                // "username": "robot",
                // "access_token": "xxx"
                // }
                String jsoStr = String.format(
                    "{\"user_id\":%d,\"username\": \"%s\",\"access_token\": \"%s\"}", userId,
                    username, accessToken);
				response.addHeader("kepp-alive", "timeout=1");
                response.getWriter().write(jsoStr);
                response.getWriter().flush();
                //response.getWriter().close();
            } else {
                response.setStatus(400);
                response.getWriter().write(EMPTY_REQUEST_JSON_STRING);
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(400);
            response.getWriter().write(MALFORMED_JSON_STRING);
        } finally {
            logger.error("Login.doPost finish" + response + response.getStatus());
        }
    }

}
