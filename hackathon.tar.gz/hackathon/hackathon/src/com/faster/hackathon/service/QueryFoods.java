package com.faster.hackathon.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;
import com.faster.hackathon.dao.impl.FoodDaoImpl;
import com.faster.hackathon.entities.Food;
import com.faster.hackathon.redis.JedisUtil;
import com.faster.hackathon.utils.JsonUtil;

/**
 * Servlet implementation class QueryFoods
 */
// @WebServlet("/foods")
public class QueryFoods extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static Logger     logger           = Logger.getLogger(QueryFoods.class);

    /**
     * @see HttpServlet#HttpServlet()
     */
    public QueryFoods() {
        super();
        // TODO Auto-generated constructor stub
    }

    @Override
    public void init() throws ServletException {
        // TODO Auto-generated method stub
        super.init();
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        try {
            logger.error("QueryFoods.doGet start");
            response.setCharacterEncoding("UTF-8");
            String accessToken = request.getParameter("access_token");
            if (accessToken == null || accessToken.isEmpty()) {
                accessToken = request.getHeader("Access-Token");
            }

            if (accessToken == null || accessToken.isEmpty()) {
                processInvalidAccessToken(response);
            } else {
                StringBuilder strBuilder = new StringBuilder(4000);
                HashMap<String, Food> mapFood = getAllFoods();
                Iterator iter = mapFood.entrySet().iterator();
                strBuilder.append("[");
                int num = 0;
                while (num < mapFood.size() - 1) {
                    Map.Entry entry = (Entry) iter.next();
                    Food food = (Food) entry.getValue();
                    strBuilder.append("{\"id\":" + food.getId() + ",\"price\":" + food.getPrice()
                                      + ",\"stock\":" + food.getStock() + "},");
                    num++;
                }
                Map.Entry entry = (Entry) iter.next();
                Food food = (Food) entry.getValue();
                strBuilder.append("{\"id\":" + food.getId() + ",\"price\":" + food.getPrice()
                                  + ",\"stock\":" + food.getStock() + "}]");
                response.getWriter().write(strBuilder.toString());
                response.getWriter().flush();
                //response.getWriter().close();

            }
        } finally {
            logger.error("QueryFoods.doGet finish");
        }
    }

    private void processInvalidAccessToken(HttpServletResponse response) throws IOException {
        response.setStatus(401);

        String str = JSON
            .toJSONString(JsonUtil.getJsonMap("code", "INVALID_ACCESS_TOKEN", "message", "��Ч������"));

        response.getWriter().write(str);
    }

    private HashMap<String, Food> getAllFoods() {

        List<String> stockValueList = JedisUtil.mgetStringValue(FoodDaoImpl.stockKeys);

        //foodid �Ǵ�1��ʼ������ע���п�
        for (int i = 0; i < stockValueList.size(); i++) {
            Food food = FoodDaoImpl.foodMap.get(String.valueOf(i + 1));
            food.setStock(Integer.valueOf(stockValueList.get(i)));
        }
        return FoodDaoImpl.foodMap;

    }
}
