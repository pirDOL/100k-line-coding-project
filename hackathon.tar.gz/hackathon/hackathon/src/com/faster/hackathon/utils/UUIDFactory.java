package com.faster.hackathon.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

public class UUIDFactory {
    public static int           capacity     = 10010;
    public static List<String>  tokenList    = new ArrayList<String>(capacity);
    public static List<String>  cartIdList   = new ArrayList<String>(capacity);
    public static AtomicInteger token_count  = new AtomicInteger(-1);
    public static AtomicInteger cartId_count = new AtomicInteger(-1);

    public static void init() {
        for (int i = 0; i < capacity; i++) {
            tokenList.add(i, genUUID());
            cartIdList.add(i, genUUID());
        }
        EnvDataUtil.init();
    }

    private static String genUUID() {
        return UUID.randomUUID().toString().replace("-", "");
    }

    public static String getToken() {
        int index = token_count.incrementAndGet();
        return tokenList.get(index);
    }

    public static String getCartId() {
        int index = cartId_count.incrementAndGet();
        return cartIdList.get(index);
    }
}
