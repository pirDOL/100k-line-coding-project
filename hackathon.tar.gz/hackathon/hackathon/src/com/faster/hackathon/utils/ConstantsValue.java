/**
 * hzr
 * Copyright (c) 2004-2015 All Rights Reserved.
 */
package com.faster.hackathon.utils;

/**
 * 
 * @author hzr
 * @version $Id: ConstantsValue.java, v 0.1 2015��11��8�� ����6:43:32 hzr $
 */
public class ConstantsValue {

    public static final String ID                                    = "id";
    public static final String ENCODINGTYPE                          = "UTF-8";
    public static final String ACCESS_TOKEN                          = "access_token";
    public static final String ACCESS_TOKEN_HEADER                   = "Access-Token";
    public static final String KEY_SPILITTER                         = ":";
    public static final String CART                                  = "cart";
    public static final String CART_ID                               = "cart_id";
    public static final String CODE                                  = "code";
    public static final String INVALID_ACCESS_TOKEN                  = "INVALID_ACCESS_TOKEN";
    public static final String MESSAGE                               = "message";
    public static final String MESSAGE_INVALID_TOKEN                 = "��Ч������";
    public static final String FOOD_ID                               = "food_id";
    public static final String COUNT                                 = "count";
    public static final String FOOD_NOT_FOUND                        = "FOOD_NOT_FOUND";
    public static final String MESSAGE_FOOD_NOT_FOUND                = "ʳ�ﲻ����";
    public static final String FOOD_OUT_OF_LIMIT                     = "FOOD_OUT_OF_LIMIT";
    public static final String MESSAGE_FOOD_OUT_OF_LIMIT             = "������ʳ����������������";
    public static final String NOT_AUTHORIZED_TO_ACCESS_CART         = "NOT_AUTHORIZED_TO_ACCESS_CART";
    public static final String MESSAGE_NOT_AUTHORIZED_TO_ACCESS_CART = "��Ȩ�޷���ָ��������";
    public static final String CART_NOT_FOUND                        = "CART_NOT_FOUND";
    public static final String MESSAGE_CART_NOT_FOUND                = "���Ӳ�����";
    public static final String ORDER                                 = "order";
    public static final String ORDER_ID                              = "id";
    public static final String ORDER_OUT_OF_LIMIT                    = "ORDER_OUT_OF_LIMIT";
    public static final String ORDERS                                = "orders";
    public static final String MESSAGE_ORDER_OUT_OF_LIMIT            = "ÿ���û�ֻ����һ��";
    public static final String ITEMS                                 = "items";
    public static final String TOTAL                                 = "total";
    public static final String FOOD_OUT_OF_STOCK                     = "FOOD_OUT_OF_STOCK";
    public static final String MESSAGE_FOOD_OUT_OF_STOCK             = "ʳ���治��";
    public static final String USER                                  = "user";
    public static final String PASSWORD                              = "password";
    public static final String USER_ID                               = "user_id";
    public static final int    PRE_BIT                               = 21;
    public static final int    USER_BIT_COUNT                        = 11;
    public static final String ACCESS_TOKEN_PREFIX                   = "FE901E1WE33129FE81L90";
    public static final String CART_ID_PREFIX                        = "AE90B21EC391UY9818M11";
    public static final int    TOTAL_USER_COUNT                      = 10000;
    public static final String JSON_ONE_PARAM                        = "{\"code\": \"USER_AUTH_FAIL\"}";
    public static final String JSON_TWO_PARAMS                       = "{\"code\": \"USER_AUTH_FAIL\",\"message\": \"�û������������\"}";
    public static final String ACCESS_TOKEN_KEYS                     = "access_token_keys";

    // ��������
    public static final String APP_HOST                              = "APP_HOST";
    public static final String APP_PORT                              = "APP_PORT";
    public static final String DB_HOST                               = "DB_HOST";
    public static final String DB_PORT                               = "DB_PORT";
    public static final String DB_NAME                               = "DB_NAME";
    public static final String DB_USER                               = "DB_USER";
    public static final String DB_PASS                               = "DB_PASS";
    public static final String REDIS_HOST                            = "REDIS_HOST";
    public static final String REDIS_PORT                            = "REDIS_PORT";
    public static final String PYTHONPATH                            = "PYTHONPATH";
    public static final String GOPATH                                = "GOPATH";
    public static final String JAVA_HOME                             = "JAVA_HOME";

    public static final String URL                                   = "url";
    public static final String USERNAME                              = "username";
    public static final String PAWWSORD                              = "password";

}
