/**
 * hzr
 * Copyright (c) 2004-2015 All Rights Reserved.
 */
package com.faster.hackathon.utils;

import java.util.Map;

import com.faster.hackathon.redis.JedisUtil;

/**
 * ��������
 * 
 * @author hzr
 * @version $Id: EnvDataUtil.java, v 0.1 2015��11��8�� ����9:40:50 hzr $
 */
public class EnvDataUtil {
	@Override
	public String toString() {
		return "EnvDataUtil []";
	}

	public static String APP_HOST = "127.0.0.1";
	public static int APP_PORT = 8080;

	public static String DB_HOST = "localhost";
	public static int DB_PORT = 3306;
	public static String DB_NAME = "eleme";
	public static String DB_USER = "root";
	public static String DB_PASS = "root";
	public static String REDIS_HOST = "localhost";
	public static int REDIS_PORT = 6379;

	public static String PYTHONPATH = "/vagrant";
	public static String GOPATH = "/srv/gopath";
	public static String JAVA_HOME = "/usr/lib/jvm/java-8-openjdk-amd64";

	static {
		System.out.println("init env data");
		Map<String, String> envMap = System.getenv();
		if (envMap.get(ConstantsValue.APP_HOST) != null) {
			APP_HOST = envMap.get(ConstantsValue.APP_HOST);
		}

		if (envMap.get(ConstantsValue.APP_PORT) != null) {
			APP_PORT = Integer.valueOf(envMap.get(ConstantsValue.APP_PORT));
		}

		if (envMap.get(ConstantsValue.DB_HOST) != null) {
			DB_HOST = envMap.get(ConstantsValue.DB_HOST);
		}

		if (envMap.get(ConstantsValue.DB_PORT) != null) {
			DB_PORT = Integer.valueOf(envMap.get(ConstantsValue.DB_PORT));
		}

		if (envMap.get(ConstantsValue.DB_NAME) != null) {
			DB_NAME = envMap.get(ConstantsValue.DB_NAME);
		}

		if (envMap.get(ConstantsValue.DB_USER) != null) {
			DB_USER = envMap.get(ConstantsValue.DB_USER);
		}

		if (envMap.get(ConstantsValue.DB_PASS) != null) {
			DB_PASS = envMap.get(ConstantsValue.DB_PASS);
		}

		if (envMap.get(ConstantsValue.REDIS_HOST) != null) {
			REDIS_HOST = envMap.get(ConstantsValue.REDIS_HOST);
		}

		if (envMap.get(ConstantsValue.REDIS_PORT) != null) {
			REDIS_PORT = Integer.valueOf(envMap.get(ConstantsValue.REDIS_PORT));
		}
		System.out.println("APP_HOST:" + APP_HOST + " APP_PORT:" + APP_PORT + " DB_HOST:" + DB_HOST + " DB_PORT:"
				+ DB_PORT + " DB_NAME:" + DB_NAME + " DB_USER:" + DB_USER + " DB_PASS:" + DB_PASS + " REDIS_HOST:"
				+ REDIS_HOST + " REDIS_PORT:" + REDIS_PORT);
		JedisUtil.init();
	}

	public static void init() {

	}
}
