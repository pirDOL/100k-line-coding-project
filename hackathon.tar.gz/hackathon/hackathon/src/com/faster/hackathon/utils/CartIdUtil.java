package com.faster.hackathon.utils;

public class CartIdUtil {

    // public static String[] userIdToCartId = new
    // String[ConstantsValue.TOTAL_USER_COUNT + 10];

    public static void intClass() {
        // for (int i = 1; i <= ConstantsValue.TOTAL_USER_COUNT; i++) {
        // userIdToCartId[i] = ConstantsValue.CART_ID_PREFIX +
        // String.format("%05d", i);
        // }
    }

    public static boolean isValidCartId(String cartId) {
        // TODO: �ж�token��ȷ��
        if (cartId.length() == 32) {
            return true;
        }
        return false;
    }

    public static String getCartId(int userId) {
        String str = ConstantsValue.CART_ID_PREFIX + String.format("%011d", userId);
        str.intern();
        return str;
    }
}
