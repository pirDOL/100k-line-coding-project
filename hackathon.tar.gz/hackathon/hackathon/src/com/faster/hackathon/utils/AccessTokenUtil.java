/**
 * hzr
 * Copyright (c) 2004-2015 All Rights Reserved.
 */
package com.faster.hackathon.utils;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;

import com.faster.hackathon.redis.JedisUtil;

/**
 * AccessToken������
 * 
 * @author hzr
 * @version $Id: AccessTokenUtil.java, v 0.1 2015��11��5�� ����3:47:07 hzr $
 */
public class AccessTokenUtil {
    // public static String[] userIdToAccessToken = new
    // String[ConstantsValue.TOTAL_USER_COUNT + 10];
    private static Map<String, String> mapUserToken = null;
    private static Map<String, String> mapTokenUser = null;

    public static void intClass() {
        // for (int i = 1; i <= ConstantsValue.TOTAL_USER_COUNT; i++) {
        // userIdToAccessToken[i] = ConstantsValue.ACCESS_TOKEN_PREFIX +
        // String.format("%05d", i);
        // }
    }

    public static boolean isValidToken(String accessToken) {
        // TODO: �ж�token��ȷ��
        //        if (mapTokenUser.containsKey(accessToken)) {
        //         return true;
        //         }
        //return false;
        //        String value = JedisUtil.getStringValue(
        //            ConstantsValue.ACCESS_TOKEN + ConstantsValue.KEY_SPILITTER + accessToken);
        //        if (value == null || value.isEmpty())
        //            return false;
        //        else
        return true;
    }

    public static String getAccessToken() {
        //return mapUserToken.get(String.valueOf(userId));
        return UUID.randomUUID().toString().replace("-", "");
    }

    //    public static String getUserId(String accessToken) {
    //        return mapTokenUser.get(accessToken);
    //    }

    public static String getUserId(String accessToken) {
        return JedisUtil.getStringValue(
            ConstantsValue.ACCESS_TOKEN + ConstantsValue.KEY_SPILITTER + accessToken);
    }

    public static void setMapUserToken(Map<String, String> mapUserToken) {
        AccessTokenUtil.mapUserToken = mapUserToken;
        mapTokenUser = new HashMap<String, String>(12500);
        Iterator<Entry<String, String>> iter = mapUserToken.entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry entry = (Map.Entry) iter.next();
            String key = (String) entry.getKey();
            String val = (String) entry.getValue();
            mapTokenUser.put(val, key);
        }
    }

    public static void saveAccessToken(int userId, String token) {
        JedisUtil.setStringValue(ConstantsValue.ACCESS_TOKEN + ConstantsValue.KEY_SPILITTER + token,
            String.valueOf(userId));
    }
}
