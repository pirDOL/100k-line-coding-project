/**
 * hzr
 * Copyright (c) 2004-2015 All Rights Reserved.
 */
package com.faster.hackathon.dao;

import java.util.List;

import com.faster.hackathon.entities.Food;

/**
 * 
 * @author  hzr
 * @version $Id: FoodDao.java, v 0.1 2015��11��5�� ����3:43:42 hzr  $
 */
public interface FoodDao {

    public Food getFood(int foodId);

    public int getFoodStock(int foodId);

    public int getFoodPrice(int foodId);

    public List<Food> getAllFoods();

    /**
     * ����ʳ����
     * 
     * @param foodId
     */
    public void updateFoodStock(int foodId);
}
