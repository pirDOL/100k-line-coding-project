/**
 * hzr
 * Copyright (c) 2004-2015 All Rights Reserved.
 */
package com.faster.hackathon.dao;

/**
 * ����
 * 
 * @author  hzr
 * @version $Id: PurchaseDao.java, v 0.1 2015��11��5�� ����3:52:19 hzr  $
 */
public interface PurchaseDao {

    /**
     * ��������
     * @param accessToken
     * @param cartId
     */
    public void saveCart(String accessToken, String cartId);

    /**
     * ����ʳ��
     * 
     * @param foodId
     * @param count
     * @param accessToken
     * @param cartId
     * @return �Ƿ����ӳɹ�
     */
    public boolean addFood(int foodId, int count, String accessToken, String cartId);

    /**
     * �µ�
     * 
     * @param accessToken
     * @param cartId
     * @return
     */
    public boolean purchaseOrder(String accessToken, String cartId);

}
