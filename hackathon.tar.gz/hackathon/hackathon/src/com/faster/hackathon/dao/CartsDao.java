/**
 * hzr
 * Copyright (c) 2004-2015 All Rights Reserved.
 */
package com.faster.hackathon.dao;

/**
 * ���ﳵ
 * 
 * @author  hzr
 * @version $Id: CartsDao.java, v 0.1 2015��11��6�� ����2:24:01 hzr  $
 */
public interface CartsDao {

    public void saveCartsId(String accessToken, String cardId);

    public void getCartsId(String accessToken);
}
