/**
 * hzr
 * Copyright (c) 2004-2015 All Rights Reserved.
 */
package com.faster.hackathon.dao.impl;

import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import com.faster.hackathon.dao.UserDao;
import com.faster.hackathon.entities.User;
import com.faster.hackathon.redis.JedisUtil;
import com.faster.hackathon.utils.ConstantsValue;
import com.faster.hackathon.utils.EnvDataUtil;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapClientBuilder;

/**
 * 
 * @author hzr
 * @version $Id: UserDaoImpl.java, v 0.1 2015��11��6�� ����8:31:55 hzr $
 */
public class UserDaoImpl implements UserDao {
	private static SqlMapClient sqlMapClient = null;
	public static Map<String, User> userMap;

	static {
		try {
			InputStream in = JedisUtil.class.getClassLoader()
					.getResourceAsStream("com/faster/hackathon/resource/SqlMapconfig.xml");
			Properties props = new Properties();
			props = new Properties();
			props.setProperty(ConstantsValue.URL,
					"jdbc:mysql://" + EnvDataUtil.DB_HOST + ":" + EnvDataUtil.DB_PORT + "/" + EnvDataUtil.DB_NAME);
			props.setProperty(ConstantsValue.USERNAME, EnvDataUtil.DB_USER);
			props.setProperty(ConstantsValue.PAWWSORD, EnvDataUtil.DB_PASS);
			sqlMapClient = SqlMapClientBuilder.buildSqlMapClient(in, props);
			in.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * @see com.faster.hackathon.dao.UserDao#getUserById(int)
	 */
	@Override
	public User getUserById(int userId) {
		User user = null;
		try {
			user = (User) sqlMapClient.queryForObject("selectUserById", userId);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return user;
	}

	/**
	 * @see com.faster.hackathon.dao.UserDao#getUserByName(java.lang.String)
	 */
	@Override
	public User getUserByName(String name) {
		User user = null;
		try {
			user = (User) sqlMapClient.queryForObject("selectUserByName", name);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return user;
	}

	/**
	 * @see com.faster.hackathon.dao.UserDao#getPassword(int)
	 */
	@Override
	public String getPassword(int userId) {
		String password = null;
		try {
			password = (String) sqlMapClient.queryForObject("selectPasswordById", userId);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return password;
	}

	@Override
	public List<User> getAllUsers() {
		// TODO Auto-generated method stub
		List<User> users = null;
		try {
			users = (List<User>) sqlMapClient.queryForList("selectAllUser");
		} catch (Exception e) {

		}
		return users;
	}

	@Override
	public Map<String, User> getUserMap() {
		// TODO Auto-generated method stub
		return userMap;
	}

	@Override
	public void setUserMap(Map<String, User> map) {
		// TODO Auto-generated method stub
		this.userMap = map;
	}

}
