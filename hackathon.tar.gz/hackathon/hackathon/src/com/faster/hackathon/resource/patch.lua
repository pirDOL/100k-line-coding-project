if redis.call('EXISTS', KEYS[1]) == 0 then
	return 2
end

local count = tonumber(ARGV[2])
local nCounts_cart_key = 'nCounts:' .. ARGV[3]
local nCounts = redis.call('GET', nCounts_cart_key)
if nCounts == false or nCounts == '0' then
	if count <= 0 then
		return 0
	elseif count <= 3 then
		redis.call('SET', nCounts_cart_key, count)
		redis.call('HSET', KEYS[1], ARGV[1], count)
		return 0
	else
		return 1
	end
end

nCounts = nCounts + count
local curCount = redis.call('HGET', KEYS[1], ARGV[1])
if curCount == false or curCount == '0' then
	if count < 0 then
		return 0
	elseif nCounts <= 3 then
		redis.call('SET', nCounts_cart_key, nCounts)
        redis.call('HSET', KEYS[1], ARGV[1], count)
        return 0
	end
end

if nCounts > 3 or nCounts < 0 then
    return 1
end
curCount = curCount + count
if curCount < 0 then
    return 1
end
redis.call('SET', nCounts_cart_key, nCounts)
redis.call('HSET', KEYS[1], ARGV[1], curCount)
return 0
