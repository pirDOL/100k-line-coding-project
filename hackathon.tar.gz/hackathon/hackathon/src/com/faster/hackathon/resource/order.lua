local foodPairs = redis.call('HGETALL', KEYS[1])
local total = #foodPairs
if total == 0 then
	return -1
end

if redis.call('SISMEMBER', 'orders', ARGV[1]) == 1 then
	return -2
end

local food_ids, stocks, counts = {}, {}, {}
local nValidFood = 0

for i = 1, total, 2 do
	if foodPairs[i] ~= '-1' and foodPairs[i + 1] ~= '0' then
		nValidFood = nValidFood + 1
		food_ids[nValidFood] = foodPairs[i]
		counts[nValidFood] = tonumber(foodPairs[i + 1])
		stocks[nValidFood] = tonumber(redis.call('GET', 'stock:' .. foodPairs[i])) - counts[nValidFood]
		if stocks[nValidFood] < 0 then
			return -3
		end
	end
end

total = 0
local items = ''
for i = 1, nValidFood do
	redis.call('SET', 'stock:' .. food_ids[i], stocks[i])
	total = total + tonumber(redis.call('GET', 'price:' .. food_ids[i])) * counts[i]
	items = items .. food_ids[i] .. ' ' .. counts[i] .. ' '
end

local order_id = redis.call('INCR', 'order_id')
redis.call('HMSET', 'order:' .. ARGV[1], 'total', total, 'items', items, 'id', order_id)
redis.call('SADD', 'orders', ARGV[1])
return order_id
