local foodPairs = redis.call('HGETALL', 'cart:' .. ARGV[1])
if foodPairs == false then
	return 4
end

local total = #foodPairs
local food_ids, stocks, counts = {}, {}, {}
local nValidFood = 0

for i = 1, total, 2 do
	if foodPairs[i] ~= 'nCounts' and foodPairs[i + 1] ~= '0' then
		nValidFood = nValidFood + 1
		food_ids[nValidFood] = foodPairs[i]
		counts[nValidFood] = tonumber(foodPairs[i + 1])
		stocks[nValidFood] = tonumber(redis.call('GET', 'stock:' .. foodPairs[i])) - counts[nValidFood]
		if stocks[nValidFood] < 0 then
			return 5
		end
	end
end

total = 0
local items = ''
for i = 1, nValidFood do
	redis.call('SET', 'stock:' .. food_ids[i], stocks[i])
	total = total + tonumber(redis.call('GET', 'price:' .. food_ids[i])) * counts[i]
	items = items .. food_ids[i] .. ' ' .. counts[i] .. ' '
end

local order_id = redis.call('INCR', 'order_id')
redis.call('HMSET', KEYS[1], 'total', total, 'items', items, 'id', order_id)
redis.call('LPUSH', 'orders', ARGV[1])
return 0
