package com.faster.hackathon.app;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.apache.log4j.PropertyConfigurator;

import com.faster.hackathon.service.Carts;
import com.faster.hackathon.service.Order;
import com.faster.hackathon.utils.AccessTokenUtil;
import com.faster.hackathon.utils.UUIDFactory;

/**
 * Servlet implementation class Startup
 */

public class Startup extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public Startup() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see Servlet#init(ServletConfig)
     */
    public void init(ServletConfig config) throws ServletException {
        // TODO Auto-generated method stub
        PropertyConfigurator.configure(Startup.class.getClassLoader()
            .getResourceAsStream("com/faster/hackathon/resource/log4j.properties"));

        // SimpleDateFormat format = new
        // SimpleDateFormat("yyyy-MM-dd-HH:mm:ss");
        // Date d = new Date();
        // String time = format.format(d);
        // DailyRollingFileAppender appender = (DailyRollingFileAppender)
        // Logger.getRootLogger().getAppender("D");
        // appender.setFile("./logs/debug_" + time + ".log");// ��̬���޸�����ļ���
        // appender.activateOptions();
        //
        // DailyRollingFileAppender appender2 = (DailyRollingFileAppender)
        // Logger.getRootLogger().getAppender("E");
        // appender2.setFile(".logs/error_" + time + ".log");// ��̬���޸�����ļ���
        // appender2.activateOptions();
        UUIDFactory.init();
        AccessTokenUtil.intClass();
        Carts.initClass();
        Order.initClass();
    }

}
