/**
 * hzr
 * Copyright (c) 2004-2015 All Rights Reserved.
 */
package com.faster.hackathon.app;

import java.net.InetSocketAddress;

import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.webapp.WebAppContext;

/**
 * 
 * @author hzr
 * @version $Id: AppMain.java, v 0.1 2015��11��9�� ����8:26:36 hzr $
 */
public class AppMain {

	/**
	 * 
	 * @param args
	 *            args[0] ip args[1] port args[2] war or path
	 */

	public static void main(String[] args) throws Exception {

		if (args.length != 3) {
			System.out.println("Args error. Please input 3 args: args[0]:ip  args[1]:port args[2]:war or path");
			return;
		}

		System.out.println(args[0] + " " + args[1] + " " + args[2]);

		InetSocketAddress address = new InetSocketAddress(args[0], Integer.valueOf(args[1]));
		Server server = new Server(address);
		WebAppContext webapp = new WebAppContext();
		if (args[2].contains("war")) {
			webapp.setWar(args[2]);
		} else {
			webapp.setResourceBase(args[2]);
		}

		server.setHandler(webapp);

		server.start();
		server.join();
	}

}
