export APP_HOST=0.0.0.0
export APP_PORT=8080
export DB_HOST=localhost
export DB_USER=guest
export DB_PASS=111111
export REDIS_HOST=localhost
